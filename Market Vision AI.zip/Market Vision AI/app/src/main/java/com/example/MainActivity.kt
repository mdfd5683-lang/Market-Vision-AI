package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.ui.LiveScreenAnalyzerScreen
import com.example.ui.theme.MarketSignalTheme
import com.example.ui.theme.TerminalBg
import com.example.viewmodel.LiveAnalyzerViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: LiveAnalyzerViewModel by viewModels()

    private val prefs by lazy { getSharedPreferences("app_prefs", MODE_PRIVATE) }

    private var pendingStartAfterNotifPermission = false

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted && pendingStartAfterNotifPermission) {
                pendingStartAfterNotifPermission = false
                startOverlayInternal()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MarketSignalTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = TerminalBg
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {

                        // তোমার আগের স্ক্রিন (এটা পরিবর্তন করিনি)
                        LiveScreenAnalyzerScreen(viewModel = viewModel)

                        // নতুন: Overlay start/stop FAB
                        OverlayFab(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(16.dp)
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // ইউজার যদি Overlay ON করে রাখে, আর permission দিয়ে দেয়, তাহলে ফের চালু হবে
        if (isOverlayWanted() && Settings.canDrawOverlays(this)) {
            startOverlayInternal()
        }
    }

    @Composable
    private fun OverlayFab(modifier: Modifier = Modifier) {
        val overlayWantedState = remember { mutableStateOf(isOverlayWanted()) }

        FloatingActionButton(
            modifier = modifier,
            onClick = {
                if (overlayWantedState.value) {
                    stopFloatingOverlay()
                    overlayWantedState.value = false
                } else {
                    // প্রথমে ON হিসেবে সেভ করি, তারপর permission/Service স্টার্ট ট্রাই করি
                    setOverlayWanted(true)
                    val started = startOverlayInternal()
                    // permission না থাকলে started=false হবে, তখন UI state OFF রাখি
                    if (!started) {
                        setOverlayWanted(false)
                        overlayWantedState.value = false
                    } else {
                        overlayWantedState.value = true
                    }
                }
            }
        ) {
            Text(if (overlayWantedState.value) "Overlay OFF" else "Overlay ON")
        }
    }

    private fun isOverlayWanted(): Boolean =
        prefs.getBoolean("overlay_enabled", false)

    private fun setOverlayWanted(v: Boolean) {
        prefs.edit().putBoolean("overlay_enabled", v).apply()
    }

    private fun hasPostNotificationsPermission(): Boolean {
        return Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }

    /**
     * Overlay সার্ভিস স্টার্ট করার চেষ্টা করে।
     * true = সার্ভিস স্টার্ট হয়েছে
     * false = permission দরকার/কিছু ব্লক
     */
    private fun startOverlayInternal(): Boolean {
        // 1) Android 13+ হলে notification permission না থাকলে আগে সেটা চাই
        if (!hasPostNotificationsPermission()) {
            pendingStartAfterNotifPermission = true
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return false
        }

        // 2) Overlay permission না থাকলে Settings পেজে পাঠাও
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return false
        }

        // 3) Foreground service start
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ContextCompat.startForegroundService(this, i)
        } else {
            startService(i)
        }
        return true
    }

    private fun stopFloatingOverlay() {
        setOverlayWanted(false)
        stopService(Intent(this, OverlayService::class.java))
    }
}