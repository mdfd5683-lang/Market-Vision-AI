package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.LiveScreenAnalyzerScreen
import com.example.ui.theme.MarketSignalTheme
import com.example.ui.theme.TerminalBg
import com.example.viewmodel.LiveAnalyzerViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: LiveAnalyzerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MarketSignalTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = TerminalBg
                ) {
                    LiveScreenAnalyzerScreen(viewModel = viewModel)
                }
            }
        }
    }
}
