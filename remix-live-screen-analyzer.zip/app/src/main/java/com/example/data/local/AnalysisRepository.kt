package com.example.data.local

import com.example.model.LiveAnalysisResult
import com.example.model.SessionResearchStats
import com.example.model.VerificationResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class AnalysisRepository(private val dao: AnalysisResultDao) {

    val recentAnalyses: Flow<List<LiveAnalysisResult>> = dao.getRecentAnalyses().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun saveAnalysis(result: LiveAnalysisResult) {
        dao.insertAnalysis(result.toEntity())
        dao.trimOldAnalyses()
    }

    suspend fun updateAnalysis(result: LiveAnalysisResult) {
        dao.updateAnalysis(result.toEntity())
    }

    suspend fun getAllAnalyses(): List<LiveAnalysisResult> {
        return dao.getAllAnalyses().map { it.toDomain() }
    }

    suspend fun clearAll() {
        dao.clearAll()
    }

    suspend fun getCount(): Int {
        return dao.getCount()
    }

    fun computeStats(history: List<LiveAnalysisResult>): SessionResearchStats {
        if (history.isEmpty()) return SessionResearchStats()

        val total = history.size
        val verifiedList = history.filter { it.verificationResult != VerificationResult.PENDING && it.verificationResult != VerificationResult.UNVERIFIED }
        val verified = verifiedList.size
        val correct = history.count { it.verificationResult == VerificationResult.CORRECT }
        val incorrect = history.count { it.verificationResult == VerificationResult.INCORRECT }
        val unverified = history.count { it.verificationResult == VerificationResult.UNVERIFIED }

        val accuracy = if (verified > 0) (correct.toDouble() / verified.toDouble()) * 100.0 else 0.0

        val byAsset = history
            .groupBy { it.assetSymbol }
            .mapValues { (_, list) ->
                val v = list.count { it.verificationResult == VerificationResult.CORRECT || it.verificationResult == VerificationResult.INCORRECT }
                val c = list.count { it.verificationResult == VerificationResult.CORRECT }
                if (v > 0) (c.toDouble() / v.toDouble()) * 100.0 else 0.0
            }

        val byHorizon = history
            .groupBy { it.predictionHorizon.shortLabel }
            .mapValues { (_, list) ->
                val v = list.count { it.verificationResult == VerificationResult.CORRECT || it.verificationResult == VerificationResult.INCORRECT }
                val c = list.count { it.verificationResult == VerificationResult.CORRECT }
                if (v > 0) (c.toDouble() / v.toDouble()) * 100.0 else 0.0
            }

        return SessionResearchStats(
            totalObservations = total,
            verifiedObservations = verified,
            correctObservations = correct,
            incorrectObservations = incorrect,
            unverifiedObservations = unverified,
            accuracyPercent = accuracy,
            accuracyByAsset = byAsset,
            accuracyByHorizon = byHorizon
        )
    }

    fun generateCsv(list: List<LiveAnalysisResult>): String {
        val sb = StringBuilder()
        sb.append("Timestamp,Asset,Research Horizon,Observed Direction,Confidence,Start Price,End Price,Verification Result,Platform Timer Detected,Notes\n")
        list.forEach { item ->
            val ts = item.timeFormatted
            val asset = item.assetSymbol
            val horizon = item.predictionHorizon.fullLabel
            val dir = item.observedDirection.label
            val conf = "${item.confidenceLevel.label} (${item.confidenceNumeric}%)"
            val startP = item.startPrice?.toString() ?: "N/A"
            val endP = item.endPrice?.toString() ?: "N/A"
            val ver = item.verificationResult.label
            val timerDet = if (item.visibleFeatures.platformTimerDetected) item.visibleFeatures.platformTimerText else "NOT DETECTED"
            val notes = item.reasoningSummary.replace(",", ";").replace("\"", "'")
            sb.append("\"$ts\",\"$asset\",\"$horizon\",\"$dir\",\"$conf\",\"$startP\",\"$endP\",\"$ver\",\"$timerDet\",\"$notes\"\n")
        }
        return sb.toString()
    }
}
