package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AnalysisResultDao {

    @Query("SELECT * FROM analysis_results ORDER BY timestamp DESC LIMIT 50")
    fun getRecentAnalyses(): Flow<List<AnalysisResultEntity>>

    @Query("SELECT * FROM analysis_results ORDER BY timestamp DESC")
    suspend fun getAllAnalyses(): List<AnalysisResultEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnalysis(entity: AnalysisResultEntity)

    @Update
    suspend fun updateAnalysis(entity: AnalysisResultEntity)

    @Query("DELETE FROM analysis_results WHERE id NOT IN (SELECT id FROM analysis_results ORDER BY timestamp DESC LIMIT 100)")
    suspend fun trimOldAnalyses()

    @Query("DELETE FROM analysis_results")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM analysis_results")
    suspend fun getCount(): Int
}
