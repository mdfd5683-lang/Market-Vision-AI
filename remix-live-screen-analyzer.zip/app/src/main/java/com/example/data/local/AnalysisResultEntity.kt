package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.AssetVerificationStatus
import com.example.model.ConfidenceLevel
import com.example.model.LiveAnalysisResult
import com.example.model.ObservedDirection
import com.example.model.PredictionHorizon
import com.example.model.VerificationResult
import com.example.model.VisibleMarketFeatures
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

@Entity(tableName = "analysis_results")
data class AnalysisResultEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val timeFormatted: String = "",
    val assetSymbol: String = "EUR/USD",
    val predictionHorizon: String = "MIN_1",
    val observedDirection: String = "WAIT", // UP, DOWN, NEUTRAL, UNCLEAR, WAIT
    val confidenceLevel: String = "MEDIUM", // HIGH, MEDIUM, LOW, CONFLICTED
    val confidenceNumeric: Int = 65,
    val assetVerification: String = "VERIFIED",
    val assetDetectedName: String = "",
    val confirmationStatus: String = "CONFIRMED ANALYSIS",
    val reasoningSummary: String = "",
    val bengaliAnnouncement: String = "",
    val platform: String = "NOT DETECTED",
    val chartType: String = "Candlestick",
    val chartTimeframe: String = "NOT DETECTED",
    val platformTimerDetected: Boolean = false,
    val platformTimerText: String = "NOT DETECTED",
    val currentPrice: String = "NOT DETECTED",
    val recentCandlesSummary: String = "NOT DETECTED",
    val visibleIndicators: String = "NOT DETECTED",
    val supportResistance: String = "NOT DETECTED",
    val momentum: String = "NOT DETECTED",
    val trend: String = "NOT DETECTED",
    val volatility: String = "NOT DETECTED",
    val startPrice: Double? = null,
    val endPrice: Double? = null,
    val verificationResult: String = "PENDING",
    val windowStartTimestamp: Long = timestamp,
    val windowEndTimestamp: Long = timestamp + 60000L
) {
    fun toDomain(): LiveAnalysisResult {
        val direction = try {
            ObservedDirection.valueOf(observedDirection)
        } catch (e: Exception) {
            ObservedDirection.WAIT
        }
        val confLevel = try {
            ConfidenceLevel.valueOf(confidenceLevel)
        } catch (e: Exception) {
            ConfidenceLevel.MEDIUM
        }
        val horizon = try {
            PredictionHorizon.valueOf(predictionHorizon)
        } catch (e: Exception) {
            PredictionHorizon.MIN_1
        }
        val verification = try {
            AssetVerificationStatus.valueOf(assetVerification)
        } catch (e: Exception) {
            AssetVerificationStatus.VERIFIED
        }
        val verResult = try {
            VerificationResult.valueOf(verificationResult)
        } catch (e: Exception) {
            VerificationResult.UNVERIFIED
        }
        val formattedTime = if (timeFormatted.isNotBlank()) {
            timeFormatted
        } else {
            SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(timestamp))
        }

        val features = VisibleMarketFeatures(
            platform = platform,
            chartType = chartType,
            chartTimeframe = chartTimeframe,
            platformTimerDetected = platformTimerDetected,
            platformTimerText = platformTimerText,
            currentPrice = currentPrice,
            recentCandlesSummary = recentCandlesSummary,
            visibleIndicators = visibleIndicators,
            supportResistance = supportResistance,
            momentum = momentum,
            trend = trend,
            volatility = volatility
        )

        return LiveAnalysisResult(
            id = id,
            timestamp = timestamp,
            timeFormatted = formattedTime,
            assetSymbol = assetSymbol,
            predictionHorizon = horizon,
            observedDirection = direction,
            confidenceLevel = confLevel,
            confidenceNumeric = confidenceNumeric,
            assetVerification = verification,
            assetDetectedName = assetDetectedName,
            isConfirmedAnalysis = confirmationStatus == "CONFIRMED ANALYSIS",
            confirmationStatus = confirmationStatus,
            reasoningSummary = reasoningSummary,
            bengaliAnnouncement = bengaliAnnouncement,
            visibleFeatures = features,
            startPrice = startPrice,
            endPrice = endPrice,
            verificationResult = verResult,
            windowStartTimestamp = windowStartTimestamp,
            windowEndTimestamp = windowEndTimestamp
        )
    }
}

fun LiveAnalysisResult.toEntity(): AnalysisResultEntity {
    return AnalysisResultEntity(
        id = id,
        timestamp = timestamp,
        timeFormatted = timeFormatted,
        assetSymbol = assetSymbol,
        predictionHorizon = predictionHorizon.name,
        observedDirection = observedDirection.name,
        confidenceLevel = confidenceLevel.name,
        confidenceNumeric = confidenceNumeric,
        assetVerification = assetVerification.name,
        assetDetectedName = assetDetectedName,
        confirmationStatus = confirmationStatus,
        reasoningSummary = reasoningSummary,
        bengaliAnnouncement = bengaliAnnouncement,
        platform = visibleFeatures.platform,
        chartType = visibleFeatures.chartType,
        chartTimeframe = visibleFeatures.chartTimeframe,
        platformTimerDetected = visibleFeatures.platformTimerDetected,
        platformTimerText = visibleFeatures.platformTimerText,
        currentPrice = visibleFeatures.currentPrice,
        recentCandlesSummary = visibleFeatures.recentCandlesSummary,
        visibleIndicators = visibleFeatures.visibleIndicators,
        supportResistance = visibleFeatures.supportResistance,
        momentum = visibleFeatures.momentum,
        trend = visibleFeatures.trend,
        volatility = visibleFeatures.volatility,
        startPrice = startPrice,
        endPrice = endPrice,
        verificationResult = verificationResult.name,
        windowStartTimestamp = windowStartTimestamp,
        windowEndTimestamp = windowEndTimestamp
    )
}
