package com.example.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sin
import kotlin.random.Random

data class FrameSourceItem(
    val title: String,
    val marketSymbol: String,
    val timeframe: String = "1M"
)

class LiveChartFrameProvider {

    private val sampleSources = listOf(
        FrameSourceItem(
            title = "EUR / USD Market Chart",
            marketSymbol = "EUR/USD",
            timeframe = "1M"
        ),
        FrameSourceItem(
            title = "GBP / USD Market Chart",
            marketSymbol = "GBP/USD",
            timeframe = "1M"
        ),
        FrameSourceItem(
            title = "USD / JPY Market Chart",
            marketSymbol = "USD/JPY",
            timeframe = "1M"
        ),
        FrameSourceItem(
            title = "AUD / USD Market Chart",
            marketSymbol = "AUD/USD",
            timeframe = "1M"
        ),
        FrameSourceItem(
            title = "USD / CAD Market Chart",
            marketSymbol = "USD/CAD",
            timeframe = "1M"
        ),
        FrameSourceItem(
            title = "BTC / USDT Crypto Chart",
            marketSymbol = "BTC/USDT",
            timeframe = "1M"
        ),
        FrameSourceItem(
            title = "ETH / USDT Crypto Chart",
            marketSymbol = "ETH/USDT",
            timeframe = "1M"
        ),
        FrameSourceItem(
            title = "XAU / USD Gold Spot Live",
            marketSymbol = "XAU/USD",
            timeframe = "1M"
        )
    )

    fun getAvailableSources(): List<FrameSourceItem> = sampleSources

    // Seeded generator for consistent realistic live candlestick chart rendering
    fun renderLiveChartBitmap(
        source: FrameSourceItem,
        tickIndex: Int = 0,
        width: Int = 720,
        height: Int = 400
    ): Pair<Bitmap, Double> {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Dark terminal background #0D1117
        canvas.drawColor(Color.rgb(13, 17, 23))

        val gridPaint = Paint().apply {
            color = Color.argb(35, 255, 255, 255)
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }

        val textPaint = Paint().apply {
            color = Color.rgb(150, 160, 180)
            textSize = 20f
            isAntiAlias = true
        }

        val bullPaint = Paint().apply {
            color = Color.rgb(0, 230, 153) // Neon Bull Green
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val bearPaint = Paint().apply {
            color = Color.rgb(255, 75, 95) // Neon Bear Red
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val wickPaint = Paint().apply {
            strokeWidth = 2.5f
            isAntiAlias = true
        }

        val maPaint = Paint().apply {
            color = Color.rgb(0, 210, 255) // Cyan MA line
            strokeWidth = 2.5f
            style = Paint.Style.STROKE
            isAntiAlias = true
        }

        val maFastPaint = Paint().apply {
            color = Color.rgb(255, 180, 50) // Amber Fast MA line
            strokeWidth = 2f
            style = Paint.Style.STROKE
            isAntiAlias = true
        }

        // Draw background grid lines
        for (i in 1..4) {
            val y = (height / 5f) * i
            canvas.drawLine(40f, y, width - 40f, y, gridPaint)
        }
        for (i in 1..5) {
            val x = (width / 6f) * i
            canvas.drawLine(x, 40f, x, height - 40f, gridPaint)
        }

        // Draw header info bar on chart frame (Asset, Timeframe, Platform Timer)
        val headerTitle = "${source.marketSymbol} • [${source.timeframe}] Live Shared Chart"
        val remainingTimerSec = (60 - (tickIndex % 60)).coerceIn(1, 59)
        val timerStr = String.format(Locale.US, "00:%02d", remainingTimerSec)
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

        canvas.drawText(headerTitle, 40f, 38f, textPaint.apply { color = Color.rgb(220, 230, 245); textSize = 18f; isFakeBoldText = true })

        // Draw Platform Timer Badge on Chart
        val timerBadgeRect = RectF(width - 290f, 18f, width - 180f, 48f)
        val timerBadgePaint = Paint().apply {
            color = Color.rgb(30, 41, 59)
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(timerBadgeRect, 6f, 6f, timerBadgePaint)
        canvas.drawText("⏱ $timerStr", width - 280f, 40f, textPaint.apply { color = Color.rgb(0, 220, 255); textSize = 15f; isFakeBoldText = true })

        canvas.drawText(timeStr, width - 160f, 40f, textPaint.apply { color = Color.rgb(120, 140, 165); textSize = 14f; isFakeBoldText = false })

        // Generate 24 continuous candlestick bars based on source and tickIndex
        val numCandles = 24
        val candleSpacing = (width - 120f) / numCandles
        val candleWidth = candleSpacing * 0.65f

        val basePrice = when (source.marketSymbol) {
            "BTC/USDT" -> 64250.0
            "ETH/USDT" -> 3450.0
            "EUR/USD" -> 1.08520
            "GBP/USD" -> 1.27210
            "USD/JPY" -> 155.350
            "AUD/USD" -> 0.65420
            "USD/CAD" -> 1.36840
            "XAU/USD" -> 2345.50
            else -> 5200.0
        }

        val randomSeed = (source.marketSymbol.hashCode() + (tickIndex / 2)).toLong()
        val rng = Random(randomSeed)

        var currentPrice = basePrice
        val prices = mutableListOf<Double>()
        val opens = mutableListOf<Double>()
        val closes = mutableListOf<Double>()
        val highs = mutableListOf<Double>()
        val lows = mutableListOf<Double>()

        for (i in 0 until numCandles) {
            val trendFactor = sin((tickIndex + i) * 0.35) * (basePrice * 0.003)
            val delta = (rng.nextDouble(-1.0, 1.0) * (basePrice * 0.002)) + (trendFactor * 0.15)
            val open = currentPrice
            val close = currentPrice + delta
            val high = maxOf(open, close) + rng.nextDouble(0.0, 1.0) * (basePrice * 0.001)
            val low = minOf(open, close) - rng.nextDouble(0.0, 1.0) * (basePrice * 0.001)

            currentPrice = close
            opens.add(open)
            closes.add(close)
            highs.add(high)
            lows.add(low)
            prices.add(close)
        }

        val minP = lows.minOrNull() ?: basePrice
        val maxP = highs.maxOrNull() ?: (basePrice * 1.01)
        val pRange = maxOf(maxP - minP, 0.0001)

        fun priceToY(p: Double): Float {
            val chartTop = 70f
            val chartBottom = height - 55f
            val normalized = (p - minP) / pRange
            return (chartBottom - (normalized * (chartBottom - chartTop))).toFloat()
        }

        // Draw candlesticks
        for (i in 0 until numCandles) {
            val cx = 50f + (i * candleSpacing) + (candleSpacing / 2f)
            val openY = priceToY(opens[i])
            val closeY = priceToY(closes[i])
            val highY = priceToY(highs[i])
            val lowY = priceToY(lows[i])

            val isBull = closes[i] >= opens[i]
            val paint = if (isBull) bullPaint else bearPaint
            wickPaint.color = paint.color

            // Wick
            canvas.drawLine(cx, highY, cx, lowY, wickPaint)

            // Body
            val top = minOf(openY, closeY)
            val bottom = maxOf(openY, closeY)
            val bodyHeight = maxOf(bottom - top, 2f)
            val bodyRect = RectF(cx - (candleWidth / 2f), top, cx + (candleWidth / 2f), top + bodyHeight)
            canvas.drawRoundRect(bodyRect, 2f, 2f, paint)
        }

        // Draw Fast & Slow MA Lines
        var prevX = 0f
        var prevSlowY = 0f
        var prevFastY = 0f

        for (i in 2 until numCandles) {
            val cx = 50f + (i * candleSpacing) + (candleSpacing / 2f)
            val avgSlow = (prices[i] + prices[i - 1] + prices[i - 2]) / 3.0
            val slowY = priceToY(avgSlow)
            val fastY = priceToY((prices[i] + prices[i - 1]) / 2.0)

            if (i > 2) {
                canvas.drawLine(prevX, prevSlowY, cx, slowY, maPaint)
                canvas.drawLine(prevX, prevFastY, cx, fastY, maFastPaint)
            }
            prevX = cx
            prevSlowY = slowY
            prevFastY = fastY
        }

        // Price Axis on Right
        val lastPrice = closes.last()
        val formattedLastPrice = if (basePrice < 10) String.format(Locale.US, "%.5f", lastPrice) else String.format(Locale.US, "%.2f", lastPrice)
        val lastY = priceToY(lastPrice)

        val badgePaint = Paint().apply {
            color = if (closes.last() >= opens.last()) Color.rgb(0, 200, 130) else Color.rgb(230, 60, 80)
            style = Paint.Style.FILL
        }
        val badgeRect = RectF(width - 100f, lastY - 13f, width - 10f, lastY + 13f)
        canvas.drawRoundRect(badgeRect, 4f, 4f, badgePaint)

        textPaint.color = Color.BLACK
        textPaint.textSize = 13f
        textPaint.isFakeBoldText = true
        canvas.drawText(formattedLastPrice, width - 95f, lastY + 5f, textPaint)

        return Pair(bitmap, lastPrice)
    }
}
