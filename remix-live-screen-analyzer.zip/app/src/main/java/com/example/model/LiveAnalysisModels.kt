package com.example.model

import android.graphics.Bitmap
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

enum class ObservedDirection(val label: String, val bengaliLabel: String) {
    UP("UP", "ঊর্ধ্বমুখী (UP)"),
    DOWN("DOWN", "নিম্নমুখী (DOWN)"),
    NEUTRAL("NEUTRAL", "নিরপেক্ষ (NEUTRAL)"),
    UNCLEAR("UNCLEAR", "অস্পষ্ট (UNCLEAR)"),
    WAIT("WAIT", "অপেক্ষা (WAIT)");

    fun isActionable(): Boolean = this == UP || this == DOWN
}

enum class ConfidenceLevel(val label: String, val bengaliLabel: String) {
    HIGH("HIGH", "উচ্চ (HIGH)"),
    MEDIUM("MEDIUM", "মাঝারি (MEDIUM)"),
    LOW("LOW", "নিম্ন (LOW)"),
    CONFLICTED("CONFLICTED", "দ্বন্দ্বপূর্ণ (CONFLICTED)")
}

enum class PredictionHorizon(
    val seconds: Int,
    val shortLabel: String,
    val fullLabel: String,
    val bengaliLabel: String
) {
    SEC_5(5, "5s", "5 Seconds", "পাঁচ সেকেন্ডের"),
    SEC_10(10, "10s", "10 Seconds", "দশ সেকেন্ডের"),
    SEC_30(30, "30s", "30 Seconds", "তিরিশ সেকেন্ডের"),
    MIN_1(60, "1m", "1 Minute", "এক মিনিটের"),
    MIN_5(300, "5m", "5 Minutes", "পাঁচ মিনিটের");

    companion object {
        val DEFAULT = MIN_1
    }
}

enum class AnalysisInterval(val seconds: Int, val label: String) {
    SEC_5(5, "5 Seconds"),
    SEC_10(10, "10 Seconds"),
    SEC_15(15, "15 Seconds"),
    SEC_30(30, "30 Seconds");

    companion object {
        val DEFAULT = SEC_10
    }
}

enum class ScreenShareStatus(val label: String) {
    NOT_CONNECTED("NOT CONNECTED"),
    REQUESTING_SCREEN("REQUESTING SCREEN"),
    SCREEN_SHARED("SCREEN SHARED"),
    ANALYZING("ANALYZING"),
    SCREEN_SHARE_STOPPED("SCREEN SHARE STOPPED"),
    ERROR("ERROR")
}

enum class AssetVerificationStatus(val label: String, val displayMessage: String) {
    VERIFIED("VERIFIED", "Asset verified on chart"),
    MISMATCH("MISMATCH", "Asset mismatch — please open the selected asset."),
    UNVERIFIED("UNVERIFIED", "Unable to verify asset.")
}

enum class VerificationResult(val label: String) {
    CORRECT("CORRECT"),
    INCORRECT("INCORRECT"),
    UNVERIFIED("UNVERIFIED"),
    PENDING("PENDING")
}

data class AssetOption(
    val symbol: String,
    val bengaliName: String
) {
    companion object {
        val ALL = listOf(
            AssetOption("EUR/USD", "EUR/USD"),
            AssetOption("GBP/USD", "GBP/USD"),
            AssetOption("USD/JPY", "USD/JPY"),
            AssetOption("AUD/USD", "AUD/USD"),
            AssetOption("USD/CAD", "USD/CAD"),
            AssetOption("BTC/USDT", "BTC/USDT"),
            AssetOption("ETH/USDT", "ETH/USDT"),
            AssetOption("XAU/USD", "XAU/USD (Gold)")
        )
        val DEFAULT = ALL[0]
    }
}

data class VisibleMarketFeatures(
    val platform: String = "NOT DETECTED",
    val chartType: String = "Candlestick",
    val chartTimeframe: String = "NOT DETECTED",
    val platformTimerDetected: Boolean = false,
    val platformTimerText: String = "NOT DETECTED",
    val currentPrice: String = "NOT DETECTED",
    val recentCandlesSummary: String = "NOT DETECTED",
    val visibleIndicators: String = "NOT DETECTED",
    val supportResistance: String = "NOT DETECTED",
    val momentum: String = "NOT DETECTED",
    val trend: String = "NOT DETECTED",
    val volatility: String = "NOT DETECTED"
)

data class LiveAnalysisResult(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val timeFormatted: String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(timestamp)),
    val assetSymbol: String = "EUR/USD",
    val predictionHorizon: PredictionHorizon = PredictionHorizon.MIN_1,
    val observedDirection: ObservedDirection = ObservedDirection.WAIT,
    val confidenceLevel: ConfidenceLevel = ConfidenceLevel.MEDIUM,
    val confidenceNumeric: Int = 65,
    val assetVerification: AssetVerificationStatus = AssetVerificationStatus.VERIFIED,
    val assetDetectedName: String = "",
    val isConfirmedAnalysis: Boolean = true,
    val confirmationStatus: String = "CONFIRMED ANALYSIS", // "CONFIRMED ANALYSIS" or "INSUFFICIENT CONFIRMATION"
    val reasoningSummary: String = "",
    val bengaliAnnouncement: String = "",
    val visibleFeatures: VisibleMarketFeatures = VisibleMarketFeatures(),
    val startPrice: Double? = null,
    val endPrice: Double? = null,
    val verificationResult: VerificationResult = VerificationResult.PENDING,
    val windowStartTimestamp: Long = timestamp,
    val windowEndTimestamp: Long = timestamp + (predictionHorizon.seconds * 1000L),
    val frameBitmap: Bitmap? = null
) {
    // Helper property for backward compatibility if needed
    val state: String get() = observedDirection.label
    val confidence: Int get() = confidenceNumeric
}

data class SessionResearchStats(
    val totalObservations: Int = 0,
    val verifiedObservations: Int = 0,
    val correctObservations: Int = 0,
    val incorrectObservations: Int = 0,
    val unverifiedObservations: Int = 0,
    val accuracyPercent: Double = 0.0,
    val accuracyByAsset: Map<String, Double> = emptyMap(),
    val accuracyByHorizon: Map<String, Double> = emptyMap()
)
