package com.example.time

enum class ClockSyncStatus(val label: String, val displayMessage: String) {
    SYNCED("SYNCED", "Synchronized with trusted network reference"),
    SYNCING("SYNCING", "Acquiring network clock reference..."),
    CHECKING_SYNCHRONIZATION("CHECKING SYNCHRONIZATION", "Verifying screen timer alignment..."),
    LOCAL_FALLBACK("LOCAL FALLBACK", "Network time unavailable. Using local device clock.");

    val badgeText: String
        get() = if (this == CHECKING_SYNCHRONIZATION) "CLOCK STATUS: CHECKING SYNCHRONIZATION" else "CLOCK: $label"
}

