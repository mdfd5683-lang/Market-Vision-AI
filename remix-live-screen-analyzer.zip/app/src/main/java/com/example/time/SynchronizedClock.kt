package com.example.time

import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import kotlin.math.abs

data class ClockSnapshot(
    val currentTimeMs: Long,
    val timeFormatted: String,
    val syncStatus: ClockSyncStatus,
    val isNetworkTimeAvailable: Boolean,
    val roundTripDelayMs: Long,
    val offsetMillis: Long,
    val lastSyncFormatted: String
)

/**
 * Centralized Synchronized Reference Clock Service.
 *
 * Implements monotonic timing with network/server time synchronization (SNTP + HTTP Date fallback),
 * round-trip delay compensation, outlier filtering, and exponential moving average (EMA) smoothing.
 *
 * All components in the app (prediction windows, horizons, UI clock, verification, voice)
 * MUST obtain time from this single source of truth.
 */
class SynchronizedClock private constructor() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .build()

    private val timeFormatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val windowFormatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    // Offset between synchronized epoch time and local monotonic elapsedRealtime:
    // currentTime = SystemClock.elapsedRealtime() + offsetMillis
    @Volatile
    private var offsetMillis: Long = System.currentTimeMillis() - SystemClock.elapsedRealtime()

    @Volatile
    private var syncStatus: ClockSyncStatus = ClockSyncStatus.SYNCING

    @Volatile
    private var isNetworkSynced: Boolean = false

    @Volatile
    private var roundTripDelayMs: Long = 0L

    @Volatile
    private var lastSyncTimestamp: Long = 0L

    private val _snapshot = MutableStateFlow(createCurrentSnapshot())
    val snapshot: StateFlow<ClockSnapshot> = _snapshot.asStateFlow()

    private var tickerJob: Job? = null
    private var periodicSyncJob: Job? = null

    init {
        startClockTicker()
        startPeriodicSync()
    }

    /**
     * Returns the synchronized current epoch timestamp in milliseconds.
     * Guaranteed to be monotonic and drift-free.
     */
    fun now(): Long {
        return SystemClock.elapsedRealtime() + offsetMillis
    }

    /**
     * Returns formatted synchronized time (e.g., "04:03:17").
     */
    fun nowFormatted(): String {
        return timeFormatter.format(Date(now()))
    }

    /**
     * Calculates the aligned window start for a given horizon in seconds.
     * Example: for 60s horizon, aligns to 04:03:00.000
     */
    fun getWindowStart(timeMs: Long = now(), horizonSeconds: Int): Long {
        val windowDurationMs = horizonSeconds * 1000L
        if (windowDurationMs <= 0) return timeMs
        return timeMs - (timeMs % windowDurationMs)
    }

    /**
     * Calculates the aligned window end for a given horizon in seconds.
     * Example: for 60s horizon starting at 04:03:00, ends at 04:04:00.000
     */
    fun getWindowEnd(timeMs: Long = now(), horizonSeconds: Int): Long {
        val start = getWindowStart(timeMs, horizonSeconds)
        return start + (horizonSeconds * 1000L)
    }

    /**
     * Calculates remaining milliseconds inside the current aligned research window.
     */
    fun getRemainingMillis(timeMs: Long = now(), horizonSeconds: Int): Long {
        val end = getWindowEnd(timeMs, horizonSeconds)
        return maxOf(0L, end - timeMs)
    }

    /**
     * Calculates remaining whole seconds inside the current aligned research window.
     */
    fun getRemainingSeconds(timeMs: Long = now(), horizonSeconds: Int): Int {
        val remMs = getRemainingMillis(timeMs, horizonSeconds)
        return ((remMs + 999) / 1000).toInt()
    }

    /**
     * Returns the window index (epoch window counter) for tracking window transitions.
     */
    fun getWindowIndex(timeMs: Long = now(), horizonSeconds: Int): Long {
        val windowDurationMs = horizonSeconds * 1000L
        if (windowDurationMs <= 0) return 0L
        return timeMs / windowDurationMs
    }

    /**
     * Formats a given timestamp to "HH:mm:ss".
     */
    fun formatTime(timestampMs: Long): String {
        return timeFormatter.format(Date(timestampMs))
    }

    /**
     * Formats window interval string (e.g. "04:03:00 → 04:04:00").
     */
    fun formatWindowRange(startMs: Long, endMs: Long): String {
        return "${windowFormatter.format(Date(startMs))} → ${windowFormatter.format(Date(endMs))}"
    }

    fun getSyncStatus(): ClockSyncStatus = syncStatus

    fun setPlatformDiscrepancyStatus(checking: Boolean) {
        if (checking) {
            syncStatus = ClockSyncStatus.CHECKING_SYNCHRONIZATION
        } else if (isNetworkSynced) {
            syncStatus = ClockSyncStatus.SYNCED
        } else {
            syncStatus = ClockSyncStatus.LOCAL_FALLBACK
        }
    }

    /**
     * Triggers an immediate resynchronization with network time servers.
     */
    fun syncNow() {
        scope.launch {
            performTimeSynchronization()
        }
    }

    private fun startClockTicker() {
        tickerJob?.cancel()
        tickerJob = scope.launch {
            while (isActive) {
                _snapshot.value = createCurrentSnapshot()
                delay(100L) // 10Hz smooth monotonic tick for rendering & calculations
            }
        }
    }

    private fun startPeriodicSync() {
        periodicSyncJob?.cancel()
        periodicSyncJob = scope.launch {
            // Initial sync immediately
            performTimeSynchronization()

            // Periodic resync every 90 seconds
            while (isActive) {
                delay(90_000L)
                performTimeSynchronization()
            }
        }
    }

    private suspend fun performTimeSynchronization() = withContext(Dispatchers.IO) {
        if (!isNetworkSynced) {
            syncStatus = ClockSyncStatus.SYNCING
        }

        // 1. Try SNTP (RFC 4330) with primary NTP servers
        val sntpResult = querySntpServers()
        if (sntpResult != null) {
            applyCalculatedOffset(sntpResult.first, sntpResult.second)
            return@withContext
        }

        // 2. Fallback: Query HTTP HEAD Date Header with round-trip delay compensation
        val httpResult = queryHttpTimeServers()
        if (httpResult != null) {
            applyCalculatedOffset(httpResult.first, httpResult.second)
            return@withContext
        }

        // 3. Fallback: Use local device clock
        if (!isNetworkSynced) {
            syncStatus = ClockSyncStatus.LOCAL_FALLBACK
            roundTripDelayMs = 0L
            Log.w(TAG, "Network time unavailable. Using local device system clock.")
        }
    }

    /**
     * Applies the computed offset with outlier rejection and Exponential Moving Average (EMA).
     */
    private fun applyCalculatedOffset(newOffset: Long, rtt: Long) {
        roundTripDelayMs = rtt
        lastSyncTimestamp = System.currentTimeMillis()

        if (!isNetworkSynced) {
            // First successful sync: apply directly
            offsetMillis = newOffset
            isNetworkSynced = true
            syncStatus = ClockSyncStatus.SYNCED
            Log.i(TAG, "Initial clock sync successful. Offset: $offsetMillis ms, RTT: $rtt ms")
        } else {
            val delta = abs(newOffset - offsetMillis)
            if (delta < 5000) {
                // Smooth adjustment: 80% previous + 20% new
                offsetMillis = (offsetMillis * 0.8 + newOffset * 0.2).toLong()
                syncStatus = ClockSyncStatus.SYNCED
            } else {
                // Large discrepancy (e.g. system clock jumped): update directly
                offsetMillis = newOffset
                syncStatus = ClockSyncStatus.SYNCED
            }
        }
    }

    private fun querySntpServers(): Pair<Long, Long>? {
        val ntpHosts = listOf("time.google.com", "time.cloudflare.com", "pool.ntp.org", "time.android.com")
        for (host in ntpHosts) {
            try {
                val result = requestSntp(host)
                if (result != null) return result
            } catch (e: Exception) {
                // Try next host
            }
        }
        return null
    }

    private fun requestSntp(host: String): Pair<Long, Long>? {
        var socket: DatagramSocket? = null
        return try {
            val address = InetAddress.getByName(host)
            val buffer = ByteArray(48)
            buffer[0] = 0x1B // NTP mode 3 (Client), version 3

            val requestPacket = DatagramPacket(buffer, buffer.size, address, 123)
            socket = DatagramSocket().apply {
                soTimeout = 2500
            }

            val t0 = SystemClock.elapsedRealtime()
            socket.send(requestPacket)

            val responsePacket = DatagramPacket(buffer, buffer.size)
            socket.receive(responsePacket)
            val t3 = SystemClock.elapsedRealtime()

            val rtt = t3 - t0
            val transmitTimestamp = readNtpTimestamp(buffer, 40)
            if (transmitTimestamp <= 0) return null

            // Cristian's / SNTP formula: offset = serverTime - (t0 + rtt/2)
            val calculatedOffset = transmitTimestamp - (t0 + rtt / 2)
            Pair(calculatedOffset, rtt)
        } catch (e: Exception) {
            null
        } finally {
            socket?.close()
        }
    }

    private fun readNtpTimestamp(buffer: ByteArray, offset: Int): Long {
        val seconds = read32(buffer, offset)
        val fraction = read32(buffer, offset + 4)
        if (seconds == 0L && fraction == 0L) return 0L

        // NTP epoch (1900) to Unix epoch (1970): subtract 2,208,988,800 seconds
        val unixSeconds = seconds - 2208988800L
        val unixMillis = (unixSeconds * 1000L) + ((fraction * 1000L) / 0x100000000L)
        return unixMillis
    }

    private fun read32(buffer: ByteArray, offset: Int): Long {
        val b0 = buffer[offset].toLong() and 0xFF
        val b1 = buffer[offset + 1].toLong() and 0xFF
        val b2 = buffer[offset + 2].toLong() and 0xFF
        val b3 = buffer[offset + 3].toLong() and 0xFF
        return (b0 shl 24) or (b1 shl 16) or (b2 shl 8) or b3
    }

    private fun queryHttpTimeServers(): Pair<Long, Long>? {
        val httpEndpoints = listOf(
            "https://www.google.com",
            "https://www.cloudflare.com",
            "https://httpbin.org/get"
        )

        val httpDateFormat = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("GMT")
        }

        for (url in httpEndpoints) {
            try {
                val request = Request.Builder()
                    .url(url)
                    .head()
                    .header("User-Agent", "RemixLiveScreenAnalyzer/1.0")
                    .build()

                val t0 = SystemClock.elapsedRealtime()
                httpClient.newCall(request).execute().use { response ->
                    val t3 = SystemClock.elapsedRealtime()
                    val dateHeader = response.header("Date")
                    if (dateHeader != null) {
                        val serverDate = httpDateFormat.parse(dateHeader)
                        if (serverDate != null) {
                            val rtt = t3 - t0
                            val serverTimeMs = serverDate.time
                            // Cristian's algorithm:
                            val calculatedOffset = serverTimeMs - (t0 + rtt / 2)
                            return Pair(calculatedOffset, rtt)
                        }
                    }
                }
            } catch (e: Exception) {
                // Try next endpoint
            }
        }
        return null
    }

    private fun createCurrentSnapshot(): ClockSnapshot {
        val current = now()
        return ClockSnapshot(
            currentTimeMs = current,
            timeFormatted = timeFormatter.format(Date(current)),
            syncStatus = syncStatus,
            isNetworkTimeAvailable = isNetworkSynced,
            roundTripDelayMs = roundTripDelayMs,
            offsetMillis = offsetMillis,
            lastSyncFormatted = if (lastSyncTimestamp > 0) timeFormatter.format(Date(lastSyncTimestamp)) else "None"
        )
    }

    companion object {
        private const val TAG = "SynchronizedClock"

        @Volatile
        private var INSTANCE: SynchronizedClock? = null

        fun getInstance(): SynchronizedClock {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SynchronizedClock().also { INSTANCE = it }
            }
        }
    }
}
