package com.example.ui

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.StopScreenShare
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingFlat
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.AnalysisInterval
import com.example.model.AssetOption
import com.example.model.AssetVerificationStatus
import com.example.model.ConfidenceLevel
import com.example.model.LiveAnalysisResult
import com.example.model.ObservedDirection
import com.example.model.PredictionHorizon
import com.example.model.ScreenShareStatus
import com.example.model.VerificationResult
import com.example.time.ClockSyncStatus
import com.example.ui.components.FloatingOvalAssistant
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.TerminalBg
import com.example.ui.theme.TerminalBlack
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.LiveAnalyzerViewModel
import java.util.Locale

enum class AppNavCategory {
    HOME,
    MORE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveScreenAnalyzerScreen(
    viewModel: LiveAnalyzerViewModel
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var currentNavCategory by remember { mutableStateOf(AppNavCategory.HOME) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(CyanNeon.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = CyanNeon,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "LIVE MARKET AI",
                                fontWeight = FontWeight.Black,
                                fontSize = 15.sp,
                                letterSpacing = 0.8.sp,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = if (currentNavCategory == AppNavCategory.HOME) "Live Research Observation" else "Advanced Settings & History",
                                fontSize = 10.sp,
                                color = TextSecondary
                            )
                        }
                    }
                },
                navigationIcon = {
                    if (currentNavCategory == AppNavCategory.MORE) {
                        IconButton(
                            onClick = { currentNavCategory = AppNavCategory.HOME },
                            modifier = Modifier.testTag("nav_back_to_home")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back to Home",
                                tint = CyanNeon
                            )
                        }
                    }
                },
                actions = {
                    // Export CSV button
                    IconButton(
                        onClick = {
                            viewModel.exportCsv()
                            uiState.exportedCsv?.let { csv ->
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, csv)
                                    type = "text/csv"
                                }
                                val shareIntent = Intent.createChooser(sendIntent, "Export Research History CSV")
                                context.startActivity(shareIntent)
                            }
                        },
                        modifier = Modifier.testTag("export_csv_appbar_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Export Research CSV",
                            tint = CyanNeon
                        )
                    }

                    // Voice trigger
                    IconButton(
                        onClick = { viewModel.speakBengaliAnnouncement() },
                        modifier = Modifier.testTag("appbar_speak_btn")
                    ) {
                        Icon(
                            imageVector = if (uiState.isSpeaking) Icons.Default.Language else Icons.Default.VolumeUp,
                            contentDescription = "Speak Bengali Analysis",
                            tint = if (uiState.isSpeaking) CyanNeon else TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = TerminalSurface,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = TerminalBg
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Top Navigation Bar: [ HOME ] & [ ⚙ MORE ]
                TabRow(
                    selectedTabIndex = if (currentNavCategory == AppNavCategory.HOME) 0 else 1,
                    containerColor = TerminalSurface,
                    contentColor = CyanNeon,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[if (currentNavCategory == AppNavCategory.HOME) 0 else 1]),
                            color = CyanNeon,
                            height = 3.dp
                        )
                    },
                    divider = {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(TerminalBorder)
                        )
                    }
                ) {
                    Tab(
                        selected = currentNavCategory == AppNavCategory.HOME,
                        onClick = { currentNavCategory = AppNavCategory.HOME },
                        text = {
                            Text(
                                text = "HOME",
                                fontWeight = if (currentNavCategory == AppNavCategory.HOME) FontWeight.Black else FontWeight.Normal,
                                fontSize = 12.sp,
                                letterSpacing = 1.sp,
                                color = if (currentNavCategory == AppNavCategory.HOME) CyanNeon else TextMuted
                            )
                        },
                        modifier = Modifier.testTag("tab_home")
                    )
                    Tab(
                        selected = currentNavCategory == AppNavCategory.MORE,
                        onClick = { currentNavCategory = AppNavCategory.MORE },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = null,
                                    modifier = Modifier.size(13.dp),
                                    tint = if (currentNavCategory == AppNavCategory.MORE) CyanNeon else TextMuted
                                )
                                Text(
                                    text = "MORE",
                                    fontWeight = if (currentNavCategory == AppNavCategory.MORE) FontWeight.Black else FontWeight.Normal,
                                    fontSize = 12.sp,
                                    letterSpacing = 1.sp,
                                    color = if (currentNavCategory == AppNavCategory.MORE) CyanNeon else TextMuted
                                )
                            }
                        },
                        modifier = Modifier.testTag("tab_more")
                    )
                }

                // View Content
                if (currentNavCategory == AppNavCategory.HOME) {
                    HomeScreenContent(
                        uiState = uiState,
                        viewModel = viewModel,
                        onOpenMore = { currentNavCategory = AppNavCategory.MORE }
                    )
                } else {
                    MoreScreenContent(
                        uiState = uiState,
                        viewModel = viewModel,
                        onBackToHome = { currentNavCategory = AppNavCategory.HOME }
                    )
                }
            }

            // In-App Draggable Floating Oval Overlay (Enabled when START ANALYSIS is active)
            if (uiState.isAnalyzing) {
                FloatingOvalAssistant(
                    analysis = uiState.activeResearchResult,
                    selectedAsset = uiState.selectedAsset.symbol,
                    predictionHorizon = uiState.predictionHorizon,
                    remainingSeconds = uiState.windowRemainingSeconds,
                    isAnalyzing = uiState.isAnalyzing,
                    isObservingFrame = uiState.isObservingFrame,
                    isVoiceEnabled = uiState.isVoiceEnabled,
                    isMuted = uiState.isMuted,
                    isSpeaking = uiState.isSpeaking,
                    onToggleVoice = { viewModel.toggleVoice() },
                    onSpeakBengali = { viewModel.speakBengaliAnnouncement() }
                )
            }
        }
    }
}

// =========================================================================
// PART 2 & 3: CLEAN HOME SCREEN (TOP PRIMARY CONTROLS & MONITORING)
// =========================================================================

@Composable
private fun HomeScreenContent(
    uiState: com.example.viewmodel.LiveAnalyzerUiState,
    viewModel: LiveAnalyzerViewModel,
    onOpenMore: () -> Unit
) {
    var assetDropdownExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. Asset Selector [ EUR/USD ▼ ]
        Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = BorderStroke(1.dp, TerminalBorder),
            modifier = Modifier.fillMaxWidth().testTag("home_asset_selector_card")
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "ASSET SELECTOR",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 0.5.sp
                )

                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { assetDropdownExpanded = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("asset_selector_btn"),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, CyanNeon.copy(alpha = 0.6f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = TextPrimary
                        )
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${uiState.selectedAsset.symbol}  (${uiState.selectedAsset.bengaliName})",
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp,
                                color = TextPrimary
                            )
                            Text("▼", fontSize = 11.sp, color = CyanNeon)
                        }
                    }

                    DropdownMenu(
                        expanded = assetDropdownExpanded,
                        onDismissRequest = { assetDropdownExpanded = false },
                        modifier = Modifier
                            .background(TerminalSurface)
                            .border(1.dp, TerminalBorder)
                    ) {
                        AssetOption.ALL.forEach { asset ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "${asset.symbol} - ${asset.bengaliName}",
                                        color = if (asset == uiState.selectedAsset) CyanNeon else TextPrimary,
                                        fontWeight = if (asset == uiState.selectedAsset) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    viewModel.selectAsset(asset)
                                    assetDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // 2. Monitoring Display Card
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = BorderStroke(1.dp, CyanNeon.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth().testTag("home_monitoring_card")
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header & Live AI Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LIVE MONITORING",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = CyanNeon,
                        fontFamily = FontFamily.Monospace
                    )

                    // AI Monitoring Status badge
                    val aiStatusText = if (uiState.isAnalyzing) {
                        if (uiState.isPreparingNextWindow) "● PREPARING NEXT" else "● CONTINUOUSLY MONITORING"
                    } else {
                        "● IDLE"
                    }
                    val aiStatusColor = if (uiState.isAnalyzing) {
                        if (uiState.isPreparingNextWindow) AmberWarning else BullGreen
                    } else {
                        TextMuted
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = aiStatusColor.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, aiStatusColor.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "AI: $aiStatusText",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = aiStatusColor,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Current Synchronized Time Row
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = TerminalBlack,
                    border = BorderStroke(1.dp, TerminalBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Current Synchronized Time",
                                fontSize = 10.sp,
                                color = TextSecondary
                            )
                            Text(
                                text = uiState.synchronizedCurrentTimeFormatted,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = CyanNeon,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Platform Timer",
                                fontSize = 10.sp,
                                color = TextSecondary
                            )
                            Text(
                                text = if (uiState.platformTimerDetected) "DETECTED (${uiState.platformTimerText})" else "NOT DETECTED",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (uiState.platformTimerDetected) BullGreen else TextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Target Window Progress & Countdown
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Window: ${uiState.currentWindowRangeFormatted}",
                            fontSize = 10.sp,
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Remaining: ${uiState.windowRemainingFormatted}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (uiState.windowRemainingSeconds <= 10) AmberWarning else CyanNeon,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    LinearProgressIndicator(
                        progress = { uiState.windowProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (uiState.windowRemainingSeconds <= 10) AmberWarning else CyanNeon,
                        trackColor = TerminalBlack
                    )
                }
            }
        }

        // 3. Primary Controls: START ANALYSIS & STOP (Prominent at top)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { viewModel.startAnalysis() },
                enabled = !uiState.isAnalyzing,
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag("start_analysis_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BullGreen,
                    contentColor = TerminalBlack,
                    disabledContainerColor = BullGreen.copy(alpha = 0.3f),
                    disabledContentColor = TerminalBlack.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "START ANALYSIS",
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    letterSpacing = 0.5.sp
                )
            }

            Button(
                onClick = { viewModel.stopAnalysis() },
                enabled = uiState.isAnalyzing,
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .testTag("stop_analysis_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BearRed,
                    contentColor = TextPrimary,
                    disabledContainerColor = BearRed.copy(alpha = 0.25f),
                    disabledContentColor = TextMuted
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "STOP",
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    letterSpacing = 0.5.sp
                )
            }
        }

        // 4. Current & Next Research Result Card (Presented 10s before next window)
        val activeResult = uiState.activeResearchResult
        val direction = activeResult?.observedDirection ?: ObservedDirection.WAIT
        val confLevel = activeResult?.confidenceLevel ?: ConfidenceLevel.MEDIUM
        val confNumeric = activeResult?.confidenceNumeric ?: 78
        val directionColor = when (direction) {
            ObservedDirection.UP -> BullGreen
            ObservedDirection.DOWN -> BearRed
            ObservedDirection.NEUTRAL -> CyanNeon
            ObservedDirection.UNCLEAR, ObservedDirection.WAIT -> AmberWarning
        }

        val targetWindowRange = if (uiState.isAnalyzing && uiState.windowRemainingSeconds <= 10) {
            uiState.nextWindowRangeFormatted
        } else if (activeResult != null && activeResult.windowStartTimestamp > 0) {
            "${activeResult.timeFormatted} →"
        } else {
            uiState.currentWindowRangeFormatted
        }

        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = BorderStroke(2.dp, if (uiState.isAnalyzing) directionColor.copy(alpha = 0.8f) else TerminalBorder),
            modifier = Modifier.fillMaxWidth().testTag("market_research_card")
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Next Window & Status Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (uiState.windowRemainingSeconds <= 10) "NEXT WINDOW" else "RESEARCH WINDOW",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            color = CyanNeon,
                            letterSpacing = 1.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = targetWindowRange,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Status Badge
                    val statusText = when {
                        !uiState.isAnalyzing -> "IDLE"
                        uiState.isPreparingNextWindow -> "PREPARING"
                        uiState.isNextAnalysisReady || uiState.windowRemainingSeconds <= 10 -> "READY"
                        else -> "ACTIVE OBSERVATION"
                    }

                    val statusBgColor = when (statusText) {
                        "READY" -> BullGreen
                        "PREPARING" -> AmberWarning
                        "ACTIVE OBSERVATION" -> CyanNeon
                        else -> TextMuted
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = statusBgColor.copy(alpha = 0.18f),
                        border = BorderStroke(1.dp, statusBgColor.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = "STATUS: $statusText",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            color = statusBgColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Primary Direction & Confidence Row
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = TerminalBlack,
                    border = BorderStroke(1.5.dp, directionColor.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ANALYSIS:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary,
                                letterSpacing = 0.5.sp
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val directionIcon = when (direction) {
                                    ObservedDirection.UP -> Icons.Default.TrendingUp
                                    ObservedDirection.DOWN -> Icons.Default.TrendingDown
                                    ObservedDirection.NEUTRAL -> Icons.Default.TrendingFlat
                                    ObservedDirection.UNCLEAR, ObservedDirection.WAIT -> Icons.Default.Warning
                                }
                                Icon(
                                    imageVector = directionIcon,
                                    contentDescription = null,
                                    tint = directionColor,
                                    modifier = Modifier.size(24.dp)
                                )
                                Text(
                                    text = direction.label,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Black,
                                    color = directionColor,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "CONFIDENCE:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "$confNumeric%",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = directionColor,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = confLevel.label,
                                fontSize = 10.sp,
                                color = TextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                // Bengali Voice Announcement Subtitle Pill
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = TerminalBlack,
                    border = BorderStroke(1.dp, TerminalBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.speakBengaliAnnouncement() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = CyanNeon,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = if (uiState.activeAnnouncementBengali.isNotBlank()) {
                                uiState.activeAnnouncementBengali
                            } else when (direction) {
                                ObservedDirection.UP -> "আপ — $confNumeric% confidence।"
                                ObservedDirection.DOWN -> "ডাউন — $confNumeric% confidence।"
                                else -> "WAIT — signal confirmed নয়।"
                            },
                            color = TextPrimary,
                            fontSize = 11.sp,
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // 5. Navigation Button to [ ⚙ MORE / ADVANCED ]
        OutlinedButton(
            onClick = onOpenMore,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("open_more_btn"),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, CyanNeon.copy(alpha = 0.7f)),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = CyanNeon
            )
        ) {
            Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "⚙ MORE / ADVANCED SETTINGS",
                fontWeight = FontWeight.Black,
                fontSize = 12.sp,
                letterSpacing = 0.8.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

// =========================================================================
// PART 4 & 5: MORE SCREEN (SECONDARY SETTINGS, HISTORY, STATS & DIAGNOSTICS)
// =========================================================================

@Composable
private fun MoreScreenContent(
    uiState: com.example.viewmodel.LiveAnalyzerUiState,
    viewModel: LiveAnalyzerViewModel,
    onBackToHome: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "scanline")
    val scanlineY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scanline_y"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Return to Home banner
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = TerminalSurface,
            border = BorderStroke(1.dp, TerminalBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onBackToHome() }
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = null,
                        tint = CyanNeon,
                        modifier = Modifier.size(16.dp)
                    )
                    Text("Return to Live Monitoring (Home)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
                Text("HOME →", fontSize = 10.sp, color = CyanNeon, fontFamily = FontFamily.Monospace)
            }
        }

        // Section 1: Market Analysis & Research Horizon Settings
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = BorderStroke(1.dp, TerminalBorder),
            modifier = Modifier.fillMaxWidth().testTag("settings_card")
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "1. MARKET ANALYSIS SETTINGS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = CyanNeon,
                    fontFamily = FontFamily.Monospace
                )

                // Research Horizon (5s, 10s, 30s, 1m, 5m)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Timer, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(13.dp))
                        Text("Research Horizon (Analysis Window)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Text(
                        text = "Synchronized window interval for observation and result delivery.",
                        fontSize = 10.sp,
                        color = TextMuted
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf(
                            PredictionHorizon.SEC_5,
                            PredictionHorizon.SEC_10,
                            PredictionHorizon.SEC_30,
                            PredictionHorizon.MIN_1,
                            PredictionHorizon.MIN_5
                        ).forEach { horizon ->
                            val isSelected = uiState.predictionHorizon == horizon
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setPredictionHorizon(horizon) },
                                label = {
                                    Text(
                                        text = horizon.shortLabel,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanNeon.copy(alpha = 0.25f),
                                    selectedLabelColor = CyanNeon,
                                    containerColor = TerminalBlack,
                                    labelColor = TextSecondary
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = TerminalBorder,
                                    selectedBorderColor = CyanNeon
                                ),
                                modifier = Modifier.height(32.dp).testTag("horizon_chip_${horizon.seconds}")
                            )
                        }
                    }
                }

                // Screen Refresh Interval (5s, 10s, 30s)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(13.dp))
                        Text("Screen Refresh (Capture Interval)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Text(
                        text = "How often visual frames are refreshed internally.",
                        fontSize = 10.sp,
                        color = TextMuted
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf(
                            AnalysisInterval.SEC_5,
                            AnalysisInterval.SEC_10,
                            AnalysisInterval.SEC_15,
                            AnalysisInterval.SEC_30
                        ).forEach { interval ->
                            val isSelected = uiState.refreshInterval == interval
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setRefreshInterval(interval) },
                                label = {
                                    Text(
                                        text = interval.label,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyanNeon.copy(alpha = 0.25f),
                                    selectedLabelColor = CyanNeon,
                                    containerColor = TerminalBlack,
                                    labelColor = TextSecondary
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = TerminalBorder,
                                    selectedBorderColor = CyanNeon
                                ),
                                modifier = Modifier.height(32.dp).testTag("refresh_chip_${interval.seconds}")
                            )
                        }
                    }
                }
            }
        }

        // Section 2: Live Screen Sharing & Chart Preview
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = BorderStroke(1.dp, TerminalBorder),
            modifier = Modifier.fillMaxWidth().testTag("screen_share_card")
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "2. SCREEN SHARE & CHART STREAM",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = CyanNeon,
                        fontFamily = FontFamily.Monospace
                    )

                    Button(
                        onClick = {
                            if (uiState.isScreenSharing) {
                                viewModel.stopScreenShare()
                            } else {
                                viewModel.startScreenShare()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (uiState.isScreenSharing) CyanNeon else BullGreen,
                            contentColor = TerminalBlack
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(34.dp).testTag("share_live_chart_btn")
                    ) {
                        Text(
                            text = if (uiState.isScreenSharing) "CONNECTED" else "CONNECT",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Preview Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(TerminalBlack)
                        .border(
                            1.dp,
                            if (uiState.isObservingFrame) CyanNeon.copy(alpha = 0.8f) else TerminalBorder,
                            RoundedCornerShape(8.dp)
                        )
                ) {
                    if (uiState.currentFrameBitmap != null) {
                        Image(
                            bitmap = uiState.currentFrameBitmap!!.asImageBitmap(),
                            contentDescription = "Live Shared Market Chart Preview",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.FillBounds
                        )
                    } else {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Shared chart stream active.",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    if (uiState.isObservingFrame) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(2.dp)
                                .padding(top = (175 * scanlineY).dp)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(Color.Transparent, CyanNeon, Color.White, CyanNeon, Color.Transparent)
                                    )
                                )
                        )
                    }
                }
            }
        }

        // Section 3: Clock Synchronization & Platform Timer
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = BorderStroke(1.dp, TerminalBorder),
            modifier = Modifier.fillMaxWidth().testTag("sync_clock_card")
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.AccessTime, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(16.dp))
                        Text(
                            text = "3. CLOCK SYNCHRONIZATION",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = CyanNeon,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Button(
                        onClick = { viewModel.resyncClock() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyanNeon.copy(alpha = 0.2f),
                            contentColor = CyanNeon
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(32.dp).testTag("resync_clock_btn")
                    ) {
                        Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("RESYNC", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Sync Status:", fontSize = 11.sp, color = TextSecondary)
                    Text(uiState.clockSyncStatus.label, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BullGreen)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Platform Timer Detected:", fontSize = 11.sp, color = TextSecondary)
                    Text(
                        if (uiState.platformTimerDetected) "DETECTED (${uiState.platformTimerText})" else "NOT DETECTED",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (uiState.platformTimerDetected) BullGreen else TextMuted
                    )
                }
            }
        }

        // Section 4: Voice Settings & Bengali TTS
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = BorderStroke(1.dp, TerminalBorder),
            modifier = Modifier.fillMaxWidth().testTag("voice_settings_card")
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "4. BENGALI VOICE SETTINGS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = CyanNeon,
                    fontFamily = FontFamily.Monospace
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Voice Announcer On/Off", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Text("Speaks once at T-10s before research window", fontSize = 10.sp, color = TextMuted)
                    }

                    Switch(
                        checked = uiState.isVoiceEnabled,
                        onCheckedChange = { viewModel.toggleVoice() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyanNeon,
                            checkedTrackColor = CyanNeon.copy(alpha = 0.3f),
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = TerminalBlack
                        ),
                        modifier = Modifier.testTag("voice_switch")
                    )
                }

                OutlinedButton(
                    onClick = { viewModel.speakBengaliAnnouncement() },
                    modifier = Modifier.fillMaxWidth().height(38.dp),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, CyanNeon.copy(alpha = 0.5f))
                ) {
                    Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(14.dp), tint = CyanNeon)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Test Female Bengali Voice Announcement", fontSize = 11.sp, color = TextPrimary)
                }
            }
        }

        // Section 5: Session Research Statistics
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = BorderStroke(1.dp, TerminalBorder),
            modifier = Modifier.fillMaxWidth().testTag("research_stats_card")
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Assessment, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(16.dp))
                        Text(
                            text = "5. ACCURACY & SESSION REPORT",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = CyanNeon,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Text(
                        text = "${uiState.sessionStats.totalObservations} Total",
                        fontSize = 10.sp,
                        color = TextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(shape = RoundedCornerShape(6.dp), color = TerminalBlack, modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text("Verified", fontSize = 9.sp, color = TextSecondary)
                            Text("${uiState.sessionStats.verifiedObservations}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }
                    Surface(shape = RoundedCornerShape(6.dp), color = TerminalBlack, modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text("Correct", fontSize = 9.sp, color = TextSecondary)
                            Text("${uiState.sessionStats.correctObservations}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = BullGreen)
                        }
                    }
                    Surface(shape = RoundedCornerShape(6.dp), color = TerminalBlack, modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text("Incorrect", fontSize = 9.sp, color = TextSecondary)
                            Text("${uiState.sessionStats.incorrectObservations}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = BearRed)
                        }
                    }
                    Surface(shape = RoundedCornerShape(6.dp), color = TerminalBlack, modifier = Modifier.weight(1f)) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Text("Accuracy", fontSize = 9.sp, color = TextSecondary)
                            Text("${uiState.sessionStats.accuracyPercent.toInt()}%", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CyanNeon)
                        }
                    }
                }
            }
        }

        // Section 6: Research History Log
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = TerminalSurface),
            border = BorderStroke(1.dp, TerminalBorder),
            modifier = Modifier.fillMaxWidth().testTag("research_history_card")
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "6. RECENT RESEARCH LOG",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp,
                    color = CyanNeon,
                    fontFamily = FontFamily.Monospace
                )

                if (uiState.historyList.isEmpty()) {
                    Text("No past observations recorded yet in Room database.", fontSize = 11.sp, color = TextMuted)
                } else {
                    uiState.historyList.take(6).forEach { item ->
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = TerminalBlack,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${item.timeFormatted} • ${item.assetSymbol}",
                                        fontSize = 10.sp,
                                        color = TextSecondary,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = "${item.observedDirection.label} (${item.confidenceNumeric}%)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (item.observedDirection == ObservedDirection.UP) BullGreen else if (item.observedDirection == ObservedDirection.DOWN) BearRed else AmberWarning
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = when (item.verificationResult) {
                                        VerificationResult.CORRECT -> BullGreen.copy(alpha = 0.2f)
                                        VerificationResult.INCORRECT -> BearRed.copy(alpha = 0.2f)
                                        else -> CyanNeon.copy(alpha = 0.2f)
                                    }
                                ) {
                                    Text(
                                        text = item.verificationResult.label,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = when (item.verificationResult) {
                                            VerificationResult.CORRECT -> BullGreen
                                            VerificationResult.INCORRECT -> BearRed
                                            else -> CyanNeon
                                        },
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 7: Educational & Safety Disclaimer
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = TerminalBlack,
            border = BorderStroke(1.dp, AmberWarning.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth().testTag("safety_disclaimer_banner")
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = AmberWarning,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Educational & research tool for studying market chart behavior. Does NOT execute trades, submit orders, access accounts, or guarantee accuracy.",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    lineHeight = 13.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}
