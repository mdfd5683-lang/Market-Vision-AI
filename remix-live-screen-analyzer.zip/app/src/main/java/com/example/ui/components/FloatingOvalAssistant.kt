package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingFlat
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.CloseFullscreen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ConfidenceLevel
import com.example.model.LiveAnalysisResult
import com.example.model.ObservedDirection
import com.example.model.PredictionHorizon
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.TerminalBlack
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun FloatingOvalAssistant(
    analysis: LiveAnalysisResult?,
    selectedAsset: String,
    predictionHorizon: PredictionHorizon,
    remainingSeconds: Int,
    isAnalyzing: Boolean,
    isObservingFrame: Boolean,
    isVoiceEnabled: Boolean,
    isMuted: Boolean,
    isSpeaking: Boolean,
    onToggleVoice: () -> Unit,
    onSpeakBengali: () -> Unit,
    modifier: Modifier = Modifier
) {
    var offsetX by remember { mutableStateOf(16f) }
    var offsetY by remember { mutableStateOf(60f) }
    var isExpanded by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "oval_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isObservingFrame || isSpeaking) 1.03f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val spinAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin_angle"
    )

    val direction = analysis?.observedDirection ?: ObservedDirection.WAIT
    val confidenceLevel = analysis?.confidenceLevel ?: ConfidenceLevel.MEDIUM
    val confidenceNumeric = analysis?.confidenceNumeric ?: 78

    val directionColor = when (direction) {
        ObservedDirection.UP -> BullGreen
        ObservedDirection.DOWN -> BearRed
        ObservedDirection.NEUTRAL -> CyanNeon
        ObservedDirection.UNCLEAR, ObservedDirection.WAIT -> AmberWarning
    }

    val directionIcon = when (direction) {
        ObservedDirection.UP -> Icons.AutoMirrored.Filled.TrendingUp
        ObservedDirection.DOWN -> Icons.AutoMirrored.Filled.TrendingDown
        ObservedDirection.NEUTRAL -> Icons.AutoMirrored.Filled.TrendingFlat
        else -> Icons.Default.Warning
    }

    val remainingFormatted = String.format(Locale.US, "%02d:%02d", remainingSeconds / 60, remainingSeconds % 60)

    Box(
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offsetX += dragAmount.x
                    offsetY += dragAmount.y
                }
            }
            .padding(6.dp)
            .testTag("floating_oval_analyzer")
    ) {
        Surface(
            shape = RoundedCornerShape(if (isExpanded) 16.dp else 24.dp),
            color = TerminalSurface.copy(alpha = 0.95f),
            border = BorderStroke(
                1.5.dp,
                if (isSpeaking) CyanNeon else directionColor.copy(alpha = 0.8f)
            ),
            modifier = Modifier
                .shadow(12.dp, RoundedCornerShape(if (isExpanded) 16.dp else 24.dp), ambientColor = directionColor, spotColor = directionColor)
                .scale(pulseScale)
                .clickable {
                    if (!isExpanded) isExpanded = true
                }
        ) {
            if (!isExpanded) {
                // Compact Oval Mode
                Column(
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Top Header Row: Asset & Expand / Voice Button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.width(180.dp)
                    ) {
                        Column {
                            Text(
                                text = selectedAsset,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Rem: $remainingFormatted",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (remainingSeconds <= 10) AmberWarning else CyanNeon,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            IconButton(
                                onClick = onToggleVoice,
                                modifier = Modifier
                                    .size(24.dp)
                                    .background(
                                        if (isVoiceEnabled && !isMuted) CyanNeon.copy(alpha = 0.2f) else TerminalBlack,
                                        CircleShape
                                    )
                                    .border(1.dp, TerminalBorder, CircleShape)
                                    .testTag("voice_toggle_button")
                            ) {
                                Icon(
                                    imageVector = if (isVoiceEnabled && !isMuted) {
                                        if (isSpeaking) Icons.Default.GraphicEq else Icons.AutoMirrored.Filled.VolumeUp
                                    } else {
                                        Icons.AutoMirrored.Filled.VolumeOff
                                    },
                                    contentDescription = if (isVoiceEnabled) "Voice ON" else "Voice OFF",
                                    tint = if (isVoiceEnabled && !isMuted) CyanNeon else TextMuted,
                                    modifier = Modifier.size(12.dp)
                                )
                            }

                            IconButton(
                                onClick = { isExpanded = true },
                                modifier = Modifier
                                    .size(24.dp)
                                    .background(TerminalBlack, CircleShape)
                                    .border(1.dp, TerminalBorder, CircleShape)
                                    .testTag("expand_overlay_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.OpenInFull,
                                    contentDescription = "Expand Overlay",
                                    tint = CyanNeon,
                                    modifier = Modifier.size(11.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Direction & Icon Row
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.clickable { onSpeakBengali() }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .background(
                                    Brush.radialGradient(
                                        listOf(directionColor.copy(alpha = 0.35f), Color.Transparent)
                                    ),
                                    CircleShape
                                )
                                .border(1.dp, directionColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isObservingFrame) {
                                Icon(
                                    imageVector = Icons.Default.Sync,
                                    contentDescription = "Analyzing",
                                    tint = CyanNeon,
                                    modifier = Modifier
                                        .size(13.dp)
                                        .rotate(spinAngle)
                                    )
                            } else {
                                Icon(
                                    imageVector = directionIcon,
                                    contentDescription = direction.label,
                                    tint = directionColor,
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }

                        Text(
                            text = "${direction.label} $confidenceNumeric%",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            color = directionColor,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    val statusText = if (remainingSeconds <= 10 && isAnalyzing) {
                        "● NEXT WINDOW READY"
                    } else if (isObservingFrame) {
                        "● EVALUATING"
                    } else if (isAnalyzing) {
                        "● MONITORING"
                    } else {
                        "● IDLE"
                    }
                    val statusColor = if (remainingSeconds <= 10 && isAnalyzing) AmberWarning else if (isObservingFrame) CyanNeon else if (isAnalyzing) BullGreen else TextMuted

                    Text(
                        text = statusText,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                // Expanded Overlay Mode
                Column(
                    modifier = Modifier
                        .widthIn(min = 220.dp, max = 260.dp)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Header with Minimize Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = selectedAsset,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "Horizon: ${predictionHorizon.shortLabel}",
                                fontSize = 10.sp,
                                color = CyanNeon
                            )
                        }

                        IconButton(
                            onClick = { isExpanded = false },
                            modifier = Modifier
                                .size(24.dp)
                                .background(TerminalBlack, CircleShape)
                                .border(1.dp, TerminalBorder, CircleShape)
                                .testTag("minimize_overlay_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloseFullscreen,
                                contentDescription = "Minimize to Oval",
                                tint = CyanNeon,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }

                    // Result Pill
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = TerminalBlack,
                        border = BorderStroke(1.dp, directionColor.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("ANALYSIS", fontSize = 9.sp, color = TextSecondary)
                                Text(
                                    text = direction.label,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    color = directionColor,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("CONFIDENCE", fontSize = 9.sp, color = TextSecondary)
                                Text(
                                    text = "$confidenceNumeric%",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    color = directionColor,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    // Remaining and Voice
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Remaining: $remainingFormatted",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (remainingSeconds <= 10) AmberWarning else CyanNeon,
                            fontFamily = FontFamily.Monospace
                        )

                        IconButton(
                            onClick = onSpeakBengali,
                            modifier = Modifier
                                .size(26.dp)
                                .background(TerminalBlack, CircleShape)
                                .border(1.dp, TerminalBorder, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Speak",
                                tint = CyanNeon,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                    }

                    if (analysis != null && analysis.reasoningSummary.isNotBlank()) {
                        Text(
                            text = analysis.reasoningSummary,
                            fontSize = 10.sp,
                            color = TextSecondary,
                            maxLines = 2
                        )
                    }
                }
            }
        }
    }
}
