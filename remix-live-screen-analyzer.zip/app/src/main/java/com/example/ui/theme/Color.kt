package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Geometric Balance Design Theme Palette
val TerminalBlack = Color(0xFF141218)
val TerminalBg = Color(0xFF1C1B1F)
val TerminalSurface = Color(0xFF25232A)
val TerminalSurfaceVariant = Color(0xFF36343B)
val TerminalBorder = Color(0xFF49454F)

val CyanNeon = Color(0xFF80D8FF)
val CyanAccent = Color(0xFF38BDF8)
val IndigoAccent = Color(0xFFD0BCFF)

val BullGreen = Color(0xFF4ADE80)
val BullGreenDim = Color(0xFF22C55E)
val BullGreenContainer = Color(0x264ADE80)

val BearRed = Color(0xFFF87171)
val BearRedDim = Color(0xFFEF4444)
val BearRedContainer = Color(0x26F87171)

val AmberWarning = Color(0xFFFDE293)
val AmberContainer = Color(0x26FDE293)

val TextPrimary = Color(0xFFE6E1E5)
val TextSecondary = Color(0xFFCAC4D0)
val TextMuted = Color(0xFF938F99)

val FastMaColor = Color(0xFFFFD54F)
val SlowMaColor = Color(0xFF80D8FF)
val VolumeColor = Color(0xFF6B7280)

