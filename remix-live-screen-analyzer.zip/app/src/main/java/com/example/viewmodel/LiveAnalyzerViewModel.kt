package com.example.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.local.AnalysisRepository
import com.example.data.local.AppDatabase
import com.example.engine.FrameSourceItem
import com.example.engine.GeminiVisionService
import com.example.engine.LiveChartFrameProvider
import com.example.model.AnalysisInterval
import com.example.model.AssetOption
import com.example.model.AssetVerificationStatus
import com.example.model.ConfidenceLevel
import com.example.model.LiveAnalysisResult
import com.example.model.ObservedDirection
import com.example.model.PredictionHorizon
import com.example.model.ScreenShareStatus
import com.example.model.SessionResearchStats
import com.example.model.VerificationResult
import com.example.time.ClockSyncStatus
import com.example.time.SynchronizedClock
import com.example.voice.LiveVoiceManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

data class LiveAnalyzerUiState(
    val screenShareStatus: ScreenShareStatus = ScreenShareStatus.SCREEN_SHARED,
    val isScreenSharing: Boolean = true,
    val isAnalyzing: Boolean = false,
    val isObservingFrame: Boolean = false,
    val selectedAsset: AssetOption = AssetOption.DEFAULT,
    val predictionHorizon: PredictionHorizon = PredictionHorizon.DEFAULT,
    val refreshInterval: AnalysisInterval = AnalysisInterval.DEFAULT,
    val isVoiceEnabled: Boolean = true,
    val isMuted: Boolean = false,
    val isSpeaking: Boolean = false,
    val activeAnnouncementBengali: String = "",
    val activeResearchResult: LiveAnalysisResult? = null,
    val currentFrameBitmap: Bitmap? = null,
    val latestObservedPrice: Double? = null,

    // Centralized Synchronized Clock & Aligned Window Timing
    val synchronizedCurrentTimeFormatted: String = "00:00:00",
    val clockSyncStatus: ClockSyncStatus = ClockSyncStatus.SYNCING,
    val isNetworkTimeAvailable: Boolean = false,
    val currentWindowStartFormatted: String = "00:00:00",
    val currentWindowEndFormatted: String = "00:00:00",
    val currentWindowRangeFormatted: String = "00:00:00 → 00:00:00",
    val nextWindowRangeFormatted: String = "00:00:00 → 00:00:00",
    val windowRemainingSeconds: Int = 60,
    val windowRemainingFormatted: String = "00:60",
    val windowTotalSeconds: Int = 60,
    val windowProgress: Float = 1.0f,
    val platformTimerDetected: Boolean = false,
    val platformTimerText: String = "NOT DETECTED",

    // Early Preparation Phase Status (T-10s)
    val preparationStatus: String = "ACTIVE OBSERVATION",
    val isPreparingNextWindow: Boolean = false,
    val isNextAnalysisReady: Boolean = false,

    val historyList: List<LiveAnalysisResult> = emptyList(),
    val sessionStats: SessionResearchStats = SessionResearchStats(),
    val exportedCsv: String? = null,
    val statusMessage: String = "Screen shared & ready for research",
    val errorMessage: String? = null,
    val hasGeminiApiKey: Boolean = false,
    val tickCounter: Int = 0
)

class LiveAnalyzerViewModel @JvmOverloads constructor(
    application: Application,
    private val repository: AnalysisRepository = AnalysisRepository(
        AppDatabase.getDatabase(application).analysisResultDao()
    )
) : AndroidViewModel(application) {

    private val clock = SynchronizedClock.getInstance()
    private val frameProvider = LiveChartFrameProvider()
    private val visionService = GeminiVisionService()
    private var voiceManager: LiveVoiceManager? = null

    private val _uiState = MutableStateFlow(
        LiveAnalyzerUiState(
            hasGeminiApiKey = try {
                BuildConfig.GEMINI_API_KEY.isNotBlank() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY"
            } catch (e: Exception) {
                false
            }
        )
    )
    val uiState: StateFlow<LiveAnalyzerUiState> = _uiState.asStateFlow()

    private var observationLoopJob: Job? = null
    private var clockTickerJob: Job? = null
    private var preparingJob: Job? = null

    private var activeResearchWindowIndex: Long = -1L
    private var preparationTriggeredForIndex: Long = -1L
    private var preparedNextResult: LiveAnalysisResult? = null
    private var preparedForWindowIndex: Long = -1L

    // Short-term visual context history buffer
    private val recentPriceBuffer = mutableListOf<Double>()

    init {
        voiceManager = LiveVoiceManager(application) { isSpeaking, text ->
            _uiState.update { it.copy(isSpeaking = isSpeaking, activeAnnouncementBengali = text) }
        }

        // Collect Room database history reactively
        viewModelScope.launch {
            repository.recentAnalyses.collect { persistedList ->
                val stats = repository.computeStats(persistedList)
                _uiState.update { state ->
                    state.copy(
                        historyList = persistedList,
                        sessionStats = stats,
                        activeResearchResult = state.activeResearchResult ?: persistedList.firstOrNull()
                    )
                }
            }
        }

        // Start Master Monotonic Clock Monitoring Loop
        startMasterClockLoop()

        // Render initial live chart stream frame
        updateLiveChartFrame()
    }

    /**
     * Master Independent Clock Loop:
     * Calculates monotonic time, aligned window ranges, countdown remaining seconds,
     * triggers background preparation at T-10 seconds before WINDOW_START,
     * and transitions seamlessly at WINDOW_START without resetting.
     */
    private fun startMasterClockLoop() {
        clockTickerJob?.cancel()
        clockTickerJob = viewModelScope.launch {
            while (isActive) {
                val now = clock.now()
                val horizonSec = _uiState.value.predictionHorizon.seconds
                val windowStart = clock.getWindowStart(now, horizonSec)
                val windowEnd = clock.getWindowEnd(now, horizonSec)
                val remainingMs = maxOf(0L, windowEnd - now)
                val remainingSec = ((remainingMs + 999) / 1000).toInt()
                val progress = (remainingMs.toFloat() / (horizonSec * 1000f)).coerceIn(0f, 1f)
                val currentWindowIdx = clock.getWindowIndex(now, horizonSec)

                val nextWindowStart = windowEnd
                val nextWindowEnd = windowEnd + horizonSec * 1000L
                val nextWindowIdx = currentWindowIdx + 1
                val nextRangeFormatted = "${clock.formatTime(nextWindowStart)} → ${clock.formatTime(nextWindowEnd)}"

                val syncStatus = clock.getSyncStatus()
                val isNetAvail = clock.snapshot.value.isNetworkTimeAvailable

                _uiState.update { state ->
                    state.copy(
                        synchronizedCurrentTimeFormatted = clock.formatTime(now),
                        currentWindowStartFormatted = clock.formatTime(windowStart),
                        currentWindowEndFormatted = clock.formatTime(windowEnd),
                        currentWindowRangeFormatted = "${clock.formatTime(windowStart)} → ${clock.formatTime(windowEnd)}",
                        nextWindowRangeFormatted = nextRangeFormatted,
                        windowRemainingSeconds = remainingSec,
                        windowRemainingFormatted = String.format(Locale.US, "%02d:%02d", remainingSec / 60, remainingSec % 60),
                        windowTotalSeconds = horizonSec,
                        windowProgress = progress,
                        clockSyncStatus = syncStatus,
                        isNetworkTimeAvailable = isNetAvail
                    )
                }

                // Handle active analysis window lifecycle & early preparation timing
                if (_uiState.value.isAnalyzing) {
                    if (activeResearchWindowIndex == -1L) {
                        // First entry into active analysis: bind to current aligned window
                        activeResearchWindowIndex = currentWindowIdx
                        if (remainingSec > 10) {
                            executeResearchWindowAnalysis(windowStart, windowEnd)
                        } else {
                            // If started right in the last 10 seconds, prepare immediately for next window
                            prepareNextResearchWindow(nextWindowIdx, nextWindowStart, nextWindowEnd)
                            if (_uiState.value.activeResearchResult == null) {
                                executeResearchWindowAnalysis(windowStart, windowEnd)
                            }
                        }
                    } else if (currentWindowIdx != activeResearchWindowIndex) {
                        // WINDOW_START ARRIVED! Synchronized boundary transition
                        val prevIdx = activeResearchWindowIndex
                        activeResearchWindowIndex = currentWindowIdx
                        onResearchWindowBoundaryTransition(prevIdx, currentWindowIdx, windowStart, windowEnd)
                    } else {
                        // Inside the active window: Check T-10 seconds preparation rule
                        if (remainingSec <= 10 && preparationTriggeredForIndex != nextWindowIdx) {
                            preparationTriggeredForIndex = nextWindowIdx
                            prepareNextResearchWindow(nextWindowIdx, nextWindowStart, nextWindowEnd)
                        }
                    }
                }

                delay(100L) // 100ms smooth monotonic tick
            }
        }
    }

    fun selectAsset(asset: AssetOption) {
        _uiState.update { it.copy(selectedAsset = asset) }
        recentPriceBuffer.clear()
        preparedNextResult = null
        preparationTriggeredForIndex = -1L
        preparedForWindowIndex = -1L
        updateLiveChartFrame()
    }

    fun setPredictionHorizon(horizon: PredictionHorizon) {
        _uiState.update {
            it.copy(
                predictionHorizon = horizon,
                windowTotalSeconds = horizon.seconds
            )
        }
        preparedNextResult = null
        preparationTriggeredForIndex = -1L
        preparedForWindowIndex = -1L
        if (_uiState.value.isAnalyzing) {
            val now = clock.now()
            val windowStart = clock.getWindowStart(now, horizon.seconds)
            val windowEnd = clock.getWindowEnd(now, horizon.seconds)
            activeResearchWindowIndex = clock.getWindowIndex(now, horizon.seconds)
            executeResearchWindowAnalysis(windowStart, windowEnd)
        }
    }

    fun setRefreshInterval(interval: AnalysisInterval) {
        _uiState.update { it.copy(refreshInterval = interval) }
        if (_uiState.value.isAnalyzing) {
            startObservationLoop()
        }
    }

    fun startScreenShare() {
        _uiState.update {
            it.copy(
                screenShareStatus = ScreenShareStatus.SCREEN_SHARED,
                isScreenSharing = true,
                statusMessage = "Live chart screen shared",
                errorMessage = null
            )
        }
        updateLiveChartFrame()
    }

    fun stopScreenShare() {
        stopAnalysis()
        _uiState.update {
            it.copy(
                screenShareStatus = ScreenShareStatus.SCREEN_SHARE_STOPPED,
                isScreenSharing = false,
                statusMessage = "Screen sharing stopped"
            )
        }
    }

    fun onFrameCaptured(bitmap: Bitmap) {
        _uiState.update {
            it.copy(
                currentFrameBitmap = bitmap,
                screenShareStatus = ScreenShareStatus.SCREEN_SHARED,
                isScreenSharing = true
            )
        }
    }

    fun startAnalysis() {
        if (!_uiState.value.isScreenSharing) {
            _uiState.update {
                it.copy(
                    screenShareStatus = ScreenShareStatus.ERROR,
                    errorMessage = "Screen sharing is not active. Please click [ SHARE LIVE CHART ] first."
                )
            }
            return
        }

        _uiState.update {
            it.copy(
                isAnalyzing = true,
                screenShareStatus = ScreenShareStatus.ANALYZING,
                statusMessage = "Continuous background observation active",
                errorMessage = null
            )
        }

        // Start analysis inside current aligned window
        val now = clock.now()
        val horizonSec = _uiState.value.predictionHorizon.seconds
        val windowStart = clock.getWindowStart(now, horizonSec)
        val windowEnd = clock.getWindowEnd(now, horizonSec)
        val remainingMs = maxOf(0L, windowEnd - now)
        val remainingSec = ((remainingMs + 999) / 1000).toInt()
        val currentWindowIdx = clock.getWindowIndex(now, horizonSec)
        activeResearchWindowIndex = currentWindowIdx

        if (remainingSec > 10) {
            executeResearchWindowAnalysis(windowStart, windowEnd)
        } else {
            val nextWindowIdx = currentWindowIdx + 1
            val nextWindowStart = windowEnd
            val nextWindowEnd = windowEnd + horizonSec * 1000L
            prepareNextResearchWindow(nextWindowIdx, nextWindowStart, nextWindowEnd)
            executeResearchWindowAnalysis(windowStart, windowEnd)
        }

        startObservationLoop()
    }

    fun stopAnalysis() {
        preparingJob?.cancel()
        preparingJob = null
        observationLoopJob?.cancel()
        observationLoopJob = null
        activeResearchWindowIndex = -1L
        preparationTriggeredForIndex = -1L
        preparedNextResult = null
        preparedForWindowIndex = -1L

        _uiState.update {
            it.copy(
                isAnalyzing = false,
                isObservingFrame = false,
                isPreparingNextWindow = false,
                isNextAnalysisReady = false,
                preparationStatus = "IDLE",
                screenShareStatus = if (it.isScreenSharing) ScreenShareStatus.SCREEN_SHARED else ScreenShareStatus.SCREEN_SHARE_STOPPED,
                statusMessage = "Analysis stopped"
            )
        }
    }

    fun toggleVoice() {
        val newVoice = !_uiState.value.isVoiceEnabled
        voiceManager?.setVoiceEnabled(newVoice)
        _uiState.update { it.copy(isVoiceEnabled = newVoice) }
    }

    fun toggleMute() {
        val newMute = voiceManager?.toggleMute() ?: false
        _uiState.update { it.copy(isMuted = newMute) }
    }

    fun speakBengaliAnnouncement() {
        val current = _uiState.value.activeResearchResult
        if (current != null) {
            voiceManager?.announceResearchWindow(current, force = true)
        } else {
            val defaultMsg = "WAIT — signal confirmed নয়।"
            voiceManager?.speakText(defaultMsg)
        }
    }

    fun resyncClock() {
        clock.syncNow()
    }

    /**
     * Preparation Phase (Triggered at T-10 seconds before WINDOW_START):
     * Silently inspects latest chart frame, verifies readability/timing/context,
     * calculates confidence and pre-packages the confirmed result without announcing yet.
     */
    private fun prepareNextResearchWindow(targetWindowIndex: Long, windowStart: Long, windowEnd: Long) {
        preparingJob?.cancel()
        preparingJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isPreparingNextWindow = true,
                    isNextAnalysisReady = false,
                    preparationStatus = "PREPARING NEXT ANALYSIS"
                )
            }

            val state = _uiState.value
            val currentFrame = state.currentFrameBitmap ?: run {
                val pair = renderSampleFrame(state.selectedAsset.symbol, state.tickCounter)
                pair.first
            }
            val startPrice = state.latestObservedPrice

            try {
                // Cross-check latest observable factors and calculate confidence
                val rawResult = visionService.analyzeChartFrame(
                    bitmap = currentFrame,
                    targetAsset = state.selectedAsset.symbol,
                    predictionHorizon = state.predictionHorizon,
                    knownCurrentPrice = startPrice
                )

                // Enforce quality check: If not sufficiently confirmed or asset mismatched, prefer WAIT
                val isConfirmed = rawResult.isConfirmedAnalysis &&
                        rawResult.assetVerification == AssetVerificationStatus.VERIFIED &&
                        (rawResult.observedDirection == ObservedDirection.UP || rawResult.observedDirection == ObservedDirection.DOWN)

                val finalDirection = if (isConfirmed) rawResult.observedDirection else ObservedDirection.WAIT
                val finalConfNum = if (isConfirmed) rawResult.confidenceNumeric else 60
                val finalConfLevel = if (isConfirmed) rawResult.confidenceLevel else ConfidenceLevel.LOW
                val finalAnnouncement = GeminiVisionService.generateBengaliVoiceAnnouncement(
                    direction = finalDirection,
                    confidenceNumeric = finalConfNum,
                    targetAsset = state.selectedAsset.symbol,
                    predictionHorizon = state.predictionHorizon,
                    verification = rawResult.assetVerification
                )

                val prepared = rawResult.copy(
                    timestamp = windowStart,
                    timeFormatted = clock.formatTime(windowStart),
                    windowStartTimestamp = windowStart,
                    windowEndTimestamp = windowEnd,
                    observedDirection = finalDirection,
                    confidenceLevel = finalConfLevel,
                    confidenceNumeric = finalConfNum,
                    isConfirmedAnalysis = isConfirmed,
                    confirmationStatus = if (isConfirmed) "CONFIRMED ANALYSIS" else "INSUFFICIENT CONFIRMATION (WAIT)",
                    bengaliAnnouncement = finalAnnouncement
                )

                preparedNextResult = prepared
                preparedForWindowIndex = targetWindowIndex

                // Save and immediately present the prepared result 10 seconds before the window begins
                repository.saveAnalysis(prepared)

                _uiState.update {
                    it.copy(
                        activeResearchResult = prepared,
                        isPreparingNextWindow = false,
                        isNextAnalysisReady = true,
                        preparationStatus = "READY",
                        platformTimerDetected = prepared.visibleFeatures.platformTimerDetected,
                        platformTimerText = if (prepared.visibleFeatures.platformTimerDetected) prepared.visibleFeatures.platformTimerText else "NOT DETECTED",
                        activeAnnouncementBengali = finalAnnouncement
                    )
                }

                // Announce once in short Bengali female voice at T-10s
                voiceManager?.announceResearchWindow(prepared)

            } catch (e: Exception) {
                // Safe fallback to WAIT if any failure during preparation
                val fallbackWait = LiveAnalysisResult(
                    timestamp = windowStart,
                    timeFormatted = clock.formatTime(windowStart),
                    windowStartTimestamp = windowStart,
                    windowEndTimestamp = windowEnd,
                    assetSymbol = state.selectedAsset.symbol,
                    predictionHorizon = state.predictionHorizon,
                    observedDirection = ObservedDirection.WAIT,
                    confidenceLevel = ConfidenceLevel.LOW,
                    confidenceNumeric = 50,
                    assetVerification = AssetVerificationStatus.VERIFIED,
                    assetDetectedName = state.selectedAsset.symbol,
                    isConfirmedAnalysis = false,
                    confirmationStatus = "INSUFFICIENT CONFIRMATION (WAIT)",
                    reasoningSummary = "Waiting for clearer price structure before next window.",
                    bengaliAnnouncement = "WAIT — signal confirmed নয়।",
                    startPrice = startPrice,
                    frameBitmap = currentFrame
                )
                preparedNextResult = fallbackWait
                preparedForWindowIndex = targetWindowIndex

                repository.saveAnalysis(fallbackWait)

                _uiState.update {
                    it.copy(
                        activeResearchResult = fallbackWait,
                        isPreparingNextWindow = false,
                        isNextAnalysisReady = true,
                        preparationStatus = "READY (WAIT)",
                        activeAnnouncementBengali = fallbackWait.bengaliAnnouncement
                    )
                }

                voiceManager?.announceResearchWindow(fallbackWait)
            }
        }
    }

    /**
     * Executes research analysis immediately for current window (used on initial start / fallback).
     */
    private fun executeResearchWindowAnalysis(windowStart: Long, windowEnd: Long) {
        viewModelScope.launch {
            val state = _uiState.value
            val currentFrame = state.currentFrameBitmap ?: run {
                val pair = renderSampleFrame(state.selectedAsset.symbol, state.tickCounter)
                pair.first
            }
            val startPrice = state.latestObservedPrice

            _uiState.update {
                it.copy(isObservingFrame = true, preparationStatus = "ACTIVE OBSERVATION")
            }

            try {
                val rawResult = visionService.analyzeChartFrame(
                    bitmap = currentFrame,
                    targetAsset = state.selectedAsset.symbol,
                    predictionHorizon = state.predictionHorizon,
                    knownCurrentPrice = startPrice
                )

                val isConfirmed = rawResult.isConfirmedAnalysis &&
                        rawResult.assetVerification == AssetVerificationStatus.VERIFIED &&
                        (rawResult.observedDirection == ObservedDirection.UP || rawResult.observedDirection == ObservedDirection.DOWN)

                val finalDirection = if (isConfirmed) rawResult.observedDirection else ObservedDirection.WAIT
                val finalConfNum = if (isConfirmed) rawResult.confidenceNumeric else 60
                val finalAnnouncement = GeminiVisionService.generateBengaliVoiceAnnouncement(
                    direction = finalDirection,
                    confidenceNumeric = finalConfNum,
                    targetAsset = state.selectedAsset.symbol,
                    predictionHorizon = state.predictionHorizon,
                    verification = rawResult.assetVerification
                )

                val result = rawResult.copy(
                    timestamp = clock.now(),
                    timeFormatted = clock.formatTime(clock.now()),
                    windowStartTimestamp = windowStart,
                    windowEndTimestamp = windowEnd,
                    observedDirection = finalDirection,
                    confidenceNumeric = finalConfNum,
                    isConfirmedAnalysis = isConfirmed,
                    confirmationStatus = if (isConfirmed) "CONFIRMED ANALYSIS" else "INSUFFICIENT CONFIRMATION (WAIT)",
                    bengaliAnnouncement = finalAnnouncement
                )

                // Save initial window observation to Room
                repository.saveAnalysis(result)

                _uiState.update {
                    it.copy(
                        activeResearchResult = result,
                        isObservingFrame = false,
                        preparationStatus = "ACTIVE OBSERVATION",
                        platformTimerDetected = result.visibleFeatures.platformTimerDetected,
                        platformTimerText = if (result.visibleFeatures.platformTimerDetected) result.visibleFeatures.platformTimerText else "NOT DETECTED",
                        activeAnnouncementBengali = result.bengaliAnnouncement
                    )
                }

                checkPlatformTimerComparison(result.visibleFeatures.platformTimerText, state.windowRemainingSeconds)

                // Announce once at start of window
                voiceManager?.announceResearchWindow(result)

            } catch (e: Exception) {
                _uiState.update { it.copy(isObservingFrame = false) }
            }
        }
    }

    /**
     * Research window boundary transition:
     * Completes and verifies the previous window outcome,
     * immediately displays the prepared result for the new synchronized window,
     * and speaks the short Bengali voice announcement once.
     */
    private fun onResearchWindowBoundaryTransition(prevIdx: Long, currentWindowIdx: Long, windowStart: Long, windowEnd: Long) {
        viewModelScope.launch {
            completeResearchWindow()

            if (!_uiState.value.isAnalyzing) return@launch

            val prepared = preparedNextResult
            if (prepared != null && preparedForWindowIndex == currentWindowIdx) {
                // Immediately display the prepared confirmed result!
                repository.saveAnalysis(prepared)

                _uiState.update {
                    it.copy(
                        activeResearchResult = prepared,
                        isObservingFrame = false,
                        isPreparingNextWindow = false,
                        isNextAnalysisReady = false,
                        preparationStatus = "ACTIVE OBSERVATION",
                        platformTimerDetected = prepared.visibleFeatures.platformTimerDetected,
                        platformTimerText = if (prepared.visibleFeatures.platformTimerDetected) prepared.visibleFeatures.platformTimerText else "NOT DETECTED"
                    )
                }

                // Reset prepared holder for the next cycle
                preparedNextResult = null
                preparedForWindowIndex = -1L
            } else {
                // Fallback if preparation was interrupted or not yet ready
                executeResearchWindowAnalysis(windowStart, windowEnd)
            }
        }
    }

    private suspend fun completeResearchWindow() {
        val currentWindowResult = _uiState.value.activeResearchResult ?: return
        val startP = currentWindowResult.startPrice
        val endP = _uiState.value.latestObservedPrice

        val verification = if (startP != null && endP != null) {
            when (currentWindowResult.observedDirection) {
                ObservedDirection.UP -> if (endP > startP) VerificationResult.CORRECT else VerificationResult.INCORRECT
                ObservedDirection.DOWN -> if (endP < startP) VerificationResult.CORRECT else VerificationResult.INCORRECT
                ObservedDirection.NEUTRAL -> if (kotlin.math.abs(endP - startP) < (startP * 0.0002)) VerificationResult.CORRECT else VerificationResult.INCORRECT
                ObservedDirection.WAIT, ObservedDirection.UNCLEAR -> VerificationResult.UNVERIFIED
            }
        } else {
            VerificationResult.UNVERIFIED
        }

        val completedResult = currentWindowResult.copy(
            endPrice = endP,
            verificationResult = verification
        )

        repository.saveAnalysis(completedResult)
    }

    private fun checkPlatformTimerComparison(timerText: String, currentRemaining: Int) {
        if (timerText.isBlank() || timerText == "NOT DETECTED") {
            clock.setPlatformDiscrepancyStatus(false)
            return
        }

        // Attempt parsing e.g. "00:45" or "45s"
        try {
            val parts = timerText.trim().split(":")
            val seconds = if (parts.size == 2) {
                parts[0].trim().toInt() * 60 + parts[1].trim().toInt()
            } else {
                timerText.filter { it.isDigit() }.toIntOrNull()
            }

            if (seconds != null) {
                val diff = kotlin.math.abs(seconds - currentRemaining)
                if (diff > 5) {
                    clock.setPlatformDiscrepancyStatus(true)
                } else {
                    clock.setPlatformDiscrepancyStatus(false)
                }
            }
        } catch (e: Exception) {
            clock.setPlatformDiscrepancyStatus(false)
        }
    }

    /**
     * Background Observation Loop:
     * Silently captures latest visual frames at the user-selected Refresh Interval,
     * updates price buffer and internal context without disrupting active research window.
     */
    private fun startObservationLoop() {
        observationLoopJob?.cancel()
        observationLoopJob = viewModelScope.launch {
            while (isActive && _uiState.value.isAnalyzing) {
                val delayMs = _uiState.value.refreshInterval.seconds * 1000L
                delay(delayMs)

                if (!isActive || !_uiState.value.isAnalyzing) break

                val state = _uiState.value
                val tick = state.tickCounter + 1
                val pair = renderSampleFrame(state.selectedAsset.symbol, tick)

                val newPrice = pair.second
                recentPriceBuffer.add(newPrice)
                if (recentPriceBuffer.size > 20) recentPriceBuffer.removeAt(0)

                _uiState.update {
                    it.copy(
                        currentFrameBitmap = pair.first,
                        latestObservedPrice = newPrice,
                        tickCounter = tick
                    )
                }
            }
        }
    }

    private fun renderSampleFrame(symbol: String, tick: Int): Pair<Bitmap, Double> {
        val sampleSource = frameProvider.getAvailableSources().firstOrNull {
            it.marketSymbol.equals(symbol, ignoreCase = true)
        } ?: frameProvider.getAvailableSources().first()
        return frameProvider.renderLiveChartBitmap(sampleSource, tickIndex = tick)
    }

    private fun updateLiveChartFrame() {
        val pair = renderSampleFrame(_uiState.value.selectedAsset.symbol, _uiState.value.tickCounter)
        _uiState.update {
            it.copy(
                currentFrameBitmap = pair.first,
                latestObservedPrice = pair.second
            )
        }
    }

    fun exportCsv() {
        viewModelScope.launch {
            val list = repository.getAllAnalyses()
            val csv = repository.generateCsv(list)
            _uiState.update { it.copy(exportedCsv = csv) }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }

    override fun onCleared() {
        super.onCleared()
        clockTickerJob?.cancel()
        observationLoopJob?.cancel()
        voiceManager?.shutdown()
    }
}

