package com.example.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.model.LiveAnalysisResult
import java.util.Locale

class LiveVoiceManager(
    private val context: Context,
    private val onSpeechStatusChanged: (isSpeaking: Boolean, lastText: String) -> Unit = { _, _ -> }
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var isBengaliAvailable = false

    private var isVoiceEnabled = true
    private var isMuted = false

    // Track last research window ID to prevent duplicate speech
    private var lastSpokenWindowId: String? = null

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val bnLocale = Locale("bn", "BD")
            val bnResult = tts?.setLanguage(bnLocale)

            if (bnResult == TextToSpeech.LANG_MISSING_DATA || bnResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                val fallbackBn = Locale("bn")
                val fallbackResult = tts?.setLanguage(fallbackBn)
                if (fallbackResult == TextToSpeech.LANG_MISSING_DATA || fallbackResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    isBengaliAvailable = false
                    tts?.setLanguage(Locale.US)
                } else {
                    isBengaliAvailable = true
                }
            } else {
                isBengaliAvailable = true
            }

            tts?.setSpeechRate(1.1f)
            tts?.setPitch(1.0f)
            isInitialized = true

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    onSpeechStatusChanged(true, utteranceId ?: "")
                }

                override fun onDone(utteranceId: String?) {
                    onSpeechStatusChanged(false, "")
                }

                override fun onError(utteranceId: String?) {
                    onSpeechStatusChanged(false, "")
                }
            })
        }
    }

    fun setVoiceEnabled(enabled: Boolean) {
        isVoiceEnabled = enabled
        if (!enabled) {
            stop()
        }
    }

    fun setMuted(muted: Boolean) {
        isMuted = muted
        if (muted) {
            stop()
        }
    }

    fun toggleMute(): Boolean {
        isMuted = !isMuted
        if (isMuted) stop()
        return isMuted
    }

    fun isMuted(): Boolean = isMuted
    fun isVoiceEnabled(): Boolean = isVoiceEnabled

    /**
     * Called when a new research window begins.
     * Speaks only once per research window.
     */
    fun announceResearchWindow(result: LiveAnalysisResult, force: Boolean = false) {
        if (!isVoiceEnabled || isMuted) return

        if (!force && lastSpokenWindowId == result.id) {
            return
        }

        lastSpokenWindowId = result.id
        val textToSpeak = result.bengaliAnnouncement.ifBlank {
            when (result.observedDirection) {
                com.example.model.ObservedDirection.UP -> "আপ — ${result.confidenceNumeric}% confidence."
                com.example.model.ObservedDirection.DOWN -> "ডাউন — ${result.confidenceNumeric}% confidence."
                else -> "WAIT — signal confirmed নয়।"
            }
        }
        speakText(textToSpeak)
    }

    fun speakText(text: String) {
        if (!isVoiceEnabled || isMuted || !isInitialized || tts == null) return

        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, text)
        }

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, text)
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            // Ignore
        }
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            // Ignore
        }
    }
}
