package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AnalysisRepository
import com.example.data.local.AppDatabase
import com.example.engine.GeminiVisionService
import com.example.engine.LiveChartFrameProvider
import com.example.model.AnalysisInterval
import com.example.model.AssetVerificationStatus
import com.example.model.ConfidenceLevel
import com.example.model.LiveAnalysisResult
import com.example.model.ObservedDirection
import com.example.model.PredictionHorizon
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase
    private lateinit var repository: AnalysisRepository

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = AnalysisRepository(db.analysisResultDao())
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Remix Live Screen Analyzer", appName)
    }

    @Test
    fun `test bengali voice announcement formatting`() {
        val upAnnouncement = GeminiVisionService.generateBengaliVoiceAnnouncement(
            direction = ObservedDirection.UP,
            confidenceNumeric = 78,
            targetAsset = "EUR/USD"
        )
        assertEquals(
            "আপ — 78% confidence.",
            upAnnouncement
        )

        val downAnnouncement = GeminiVisionService.generateBengaliVoiceAnnouncement(
            direction = ObservedDirection.DOWN,
            confidenceNumeric = 74,
            targetAsset = "EUR/USD"
        )
        assertEquals(
            "ডাউন — 74% confidence.",
            downAnnouncement
        )

        val waitAnnouncement = GeminiVisionService.generateBengaliVoiceAnnouncement(
            direction = ObservedDirection.WAIT,
            confidenceNumeric = 50,
            targetAsset = "EUR/USD"
        )
        assertEquals(
            "WAIT — signal confirmed নয়।",
            waitAnnouncement
        )
    }

    @Test
    fun `test live chart frame provider rendering and vision analysis`() {
        val provider = LiveChartFrameProvider()
        val sources = provider.getAvailableSources()
        assertTrue(sources.isNotEmpty())

        val btcSource = sources.first()
        val (bitmap, _) = provider.renderLiveChartBitmap(btcSource, tickIndex = 5)
        assertNotNull(bitmap)
        assertEquals(720, bitmap.width)
        assertEquals(400, bitmap.height)

        val visionService = GeminiVisionService()
        val result = visionService.analyzeWithOnDeviceVision(bitmap, "EUR/USD", PredictionHorizon.MIN_1)
        assertNotNull(result)
        assertTrue(result.confidenceNumeric in 40..99)
        assertTrue(result.bengaliAnnouncement.isNotBlank())
    }

    @Test
    fun `test analysis intervals`() {
        assertEquals(10, AnalysisInterval.DEFAULT.seconds)
        assertEquals(4, AnalysisInterval.values().size)
    }

    @Test
    fun `test room database stores and limits to last results`() = runBlocking {
        // Insert 25 items
        for (i in 1..25) {
            val direction = if (i % 2 == 0) ObservedDirection.UP else ObservedDirection.DOWN
            val result = LiveAnalysisResult(
                id = "item_$i",
                timestamp = System.currentTimeMillis() + i * 1000L,
                timeFormatted = "09:00:0$i",
                assetSymbol = "EUR/USD",
                predictionHorizon = PredictionHorizon.MIN_1,
                observedDirection = direction,
                confidenceLevel = ConfidenceLevel.HIGH,
                confidenceNumeric = 70 + (i % 20),
                assetVerification = AssetVerificationStatus.VERIFIED,
                assetDetectedName = "EUR/USD",
                reasoningSummary = "Reasoning for item $i",
                bengaliAnnouncement = "Announcement $i"
            )
            repository.saveAnalysis(result)
        }

        val history = repository.recentAnalyses.first()
        assertEquals(25, history.size)
        // Verify newest item is first
        assertEquals("item_25", history.first().id)
        assertEquals("item_1", history.last().id)

        // Test clear
        repository.clearAll()
        val clearedHistory = repository.recentAnalyses.first()
        assertEquals(0, clearedHistory.size)
    }

    @Test
    fun `test live analyzer view model creation with application`() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val vm = com.example.viewmodel.LiveAnalyzerViewModel(app)
        assertNotNull(vm)
        assertEquals("EUR/USD", vm.uiState.value.selectedAsset.symbol)
        assertEquals(PredictionHorizon.MIN_1, vm.uiState.value.predictionHorizon)
        assertEquals(AnalysisInterval.SEC_10, vm.uiState.value.refreshInterval)
    }
}
